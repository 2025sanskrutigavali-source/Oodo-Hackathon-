/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Vehicle, Driver, Trip, MaintenanceLog, FuelLog, Expense, Role, User } from '../types';
import {
  SEED_VEHICLES,
  SEED_DRIVERS,
  SEED_TRIPS,
  SEED_MAINTENANCE,
  SEED_FUEL_LOGS,
  SEED_EXPENSES
} from '../seedData';

interface TransitContextType {
  // Authentication & RBAC
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  availableRoles: Role[];
  switchRole: (role: Role) => void;
  logout: () => void;

  // Data State
  vehicles: Vehicle[];
  drivers: Driver[];
  trips: Trip[];
  maintenanceLogs: MaintenanceLog[];
  fuelLogs: FuelLog[];
  expenses: Expense[];

  // CRUD Operations
  addVehicle: (vehicle: Omit<Vehicle, 'id'>) => { success: boolean; message: string };
  updateVehicle: (vehicle: Vehicle) => { success: boolean; message: string };
  deleteVehicle: (id: string) => { success: boolean; message: string };

  addDriver: (driver: Omit<Driver, 'id'>) => { success: boolean; message: string };
  updateDriver: (driver: Driver) => { success: boolean; message: string };
  deleteDriver: (id: string) => { success: boolean; message: string };

  addTrip: (trip: Omit<Trip, 'id' | 'status' | 'createdAt'>) => { success: boolean; message: string };
  dispatchTrip: (tripId: string) => { success: boolean; message: string };
  completeTrip: (tripId: string, finalOdometer: number, fuelConsumed: number, revenue: number) => { success: boolean; message: string };
  cancelTrip: (tripId: string) => { success: boolean; message: string };

  addMaintenanceLog: (log: Omit<MaintenanceLog, 'id' | 'status'>) => { success: boolean; message: string };
  closeMaintenanceLog: (logId: string, cost?: number) => { success: boolean; message: string };

  addFuelLog: (log: Omit<FuelLog, 'id'>) => { success: boolean; message: string };
  addExpense: (expense: Omit<Expense, 'id'>) => { success: boolean; message: string };

  // Theme & Offline
  darkMode: boolean;
  toggleDarkMode: () => void;
  isOffline: boolean;
  setIsOffline: (isOffline: boolean) => void;
  resetToDefault: () => void;
}

const TransitContext = createContext<TransitContextType | undefined>(undefined);

export const TransitProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load initial states from localStorage or use Seeds
  const [currentUser, setCurrentUserState] = useState<User | null>(() => {
    const stored = localStorage.getItem('transit_user');
    if (stored) return JSON.parse(stored);
    // Default logged in as Fleet Manager for ease of evaluation
    return { email: 'manager@transitops.com', name: 'Frank Miller', role: 'Fleet Manager' };
  });

  const [vehicles, setVehicles] = useState<Vehicle[]>(() => {
    const stored = localStorage.getItem('transit_vehicles');
    return stored ? JSON.parse(stored) : SEED_VEHICLES;
  });

  const [drivers, setDrivers] = useState<Driver[]>(() => {
    const stored = localStorage.getItem('transit_drivers');
    return stored ? JSON.parse(stored) : SEED_DRIVERS;
  });

  const [trips, setTrips] = useState<Trip[]>(() => {
    const stored = localStorage.getItem('transit_trips');
    return stored ? JSON.parse(stored) : SEED_TRIPS;
  });

  const [maintenanceLogs, setMaintenanceLogs] = useState<MaintenanceLog[]>(() => {
    const stored = localStorage.getItem('transit_maintenance');
    return stored ? JSON.parse(stored) : SEED_MAINTENANCE;
  });

  const [fuelLogs, setFuelLogs] = useState<FuelLog[]>(() => {
    const stored = localStorage.getItem('transit_fuel');
    return stored ? JSON.parse(stored) : SEED_FUEL_LOGS;
  });

  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const stored = localStorage.getItem('transit_expenses');
    return stored ? JSON.parse(stored) : SEED_EXPENSES;
  });

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const stored = localStorage.getItem('transit_dark_mode');
    return stored ? JSON.parse(stored) : true; // default to a cool dark mode as requested!
  });

  const [isOffline, setIsOffline] = useState<boolean>(false);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('transit_user', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('transit_vehicles', JSON.stringify(vehicles));
  }, [vehicles]);

  useEffect(() => {
    localStorage.setItem('transit_drivers', JSON.stringify(drivers));
  }, [drivers]);

  useEffect(() => {
    localStorage.setItem('transit_trips', JSON.stringify(trips));
  }, [trips]);

  useEffect(() => {
    localStorage.setItem('transit_maintenance', JSON.stringify(maintenanceLogs));
  }, [maintenanceLogs]);

  useEffect(() => {
    localStorage.setItem('transit_fuel', JSON.stringify(fuelLogs));
  }, [fuelLogs]);

  useEffect(() => {
    localStorage.setItem('transit_expenses', JSON.stringify(expenses));
  }, [expenses]);

  useEffect(() => {
    localStorage.setItem('transit_dark_mode', JSON.stringify(darkMode));
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const availableRoles: Role[] = [
    'Fleet Manager',
    'Driver',
    'Safety Officer',
    'Financial Analyst'
  ];

  const setCurrentUser = (user: User | null) => {
    setCurrentUserState(user);
  };

  const switchRole = (role: Role) => {
    if (currentUser) {
      const emailMap: Record<Role, string> = {
        'Fleet Manager': 'manager@transitops.com',
        'Driver': 'driver@transitops.com',
        'Safety Officer': 'safety@transitops.com',
        'Financial Analyst': 'analyst@transitops.com'
      };
      const nameMap: Record<Role, string> = {
        'Fleet Manager': 'Frank Miller',
        'Driver': 'Alex Rivera',
        'Safety Officer': 'Sarah Chen',
        'Financial Analyst': 'Emily Taylor'
      };
      setCurrentUserState({
        email: emailMap[role],
        name: nameMap[role],
        role
      });
    }
  };

  const logout = () => {
    setCurrentUserState(null);
  };

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  const resetToDefault = () => {
    setVehicles(SEED_VEHICLES);
    setDrivers(SEED_DRIVERS);
    setTrips(SEED_TRIPS);
    setMaintenanceLogs(SEED_MAINTENANCE);
    setFuelLogs(SEED_FUEL_LOGS);
    setExpenses(SEED_EXPENSES);
  };

  // --- VEHICLE ACTIONS ---
  const addVehicle = (newVeh: Omit<Vehicle, 'id'>) => {
    // Unique registration validation
    const regExists = vehicles.some(
      (v) => v.registrationNumber.trim().toLowerCase() === newVeh.registrationNumber.trim().toLowerCase()
    );
    if (regExists) {
      return { success: false, message: `Registration number ${newVeh.registrationNumber} already exists!` };
    }

    const vehicle: Vehicle = {
      ...newVeh,
      id: 'v_' + Date.now(),
      registrationNumber: newVeh.registrationNumber.trim().toUpperCase()
    };

    setVehicles((prev) => [...prev, vehicle]);
    return { success: true, message: 'Vehicle added successfully' };
  };

  const updateVehicle = (updatedVeh: Vehicle) => {
    // Unique registration validation (excluding self)
    const regExists = vehicles.some(
      (v) =>
        v.id !== updatedVeh.id &&
        v.registrationNumber.trim().toLowerCase() === updatedVeh.registrationNumber.trim().toLowerCase()
    );
    if (regExists) {
      return { success: false, message: `Registration number ${updatedVeh.registrationNumber} already exists!` };
    }

    setVehicles((prev) => prev.map((v) => (v.id === updatedVeh.id ? updatedVeh : v)));
    return { success: true, message: 'Vehicle updated successfully' };
  };

  const deleteVehicle = (id: string) => {
    // Check if vehicle is currently on a trip
    const vehicle = vehicles.find((v) => v.id === id);
    if (vehicle && vehicle.status === 'On Trip') {
      return { success: false, message: 'Cannot delete a vehicle currently on a trip.' };
    }
    setVehicles((prev) => prev.filter((v) => v.id !== id));
    return { success: true, message: 'Vehicle deleted successfully' };
  };

  // --- DRIVER ACTIONS ---
  const addDriver = (newDrv: Omit<Driver, 'id'>) => {
    const driver: Driver = {
      ...newDrv,
      id: 'd_' + Date.now()
    };
    setDrivers((prev) => [...prev, driver]);
    return { success: true, message: 'Driver registered successfully' };
  };

  const updateDriver = (updatedDrv: Driver) => {
    setDrivers((prev) => prev.map((d) => (d.id === updatedDrv.id ? updatedDrv : d)));
    return { success: true, message: 'Driver updated successfully' };
  };

  const deleteDriver = (id: string) => {
    const driver = drivers.find((d) => d.id === id);
    if (driver && driver.status === 'On Trip') {
      return { success: false, message: 'Cannot delete a driver currently on a active trip.' };
    }
    setDrivers((prev) => prev.filter((d) => d.id !== id));
    return { success: true, message: 'Driver profile deleted successfully' };
  };

  // --- TRIP ACTIONS ---
  const addTrip = (newTrip: Omit<Trip, 'id' | 'status' | 'createdAt'>) => {
    // Cargo weight validation against vehicle capacity
    const vehicle = vehicles.find((v) => v.id === newTrip.vehicleId);
    if (!vehicle) {
      return { success: false, message: 'Selected vehicle not found.' };
    }
    if (newTrip.cargoWeight > vehicle.maxCapacity) {
      return {
        success: false,
        message: `Cargo weight (${newTrip.cargoWeight} kg) exceeds vehicle maximum load capacity (${vehicle.maxCapacity} kg)!`
      };
    }

    // Driver eligibility validation
    const driver = drivers.find((d) => d.id === newTrip.driverId);
    if (!driver) {
      return { success: false, message: 'Selected driver not found.' };
    }

    // Checking safety criteria / expired license
    const today = new Date().toISOString().split('T')[0];
    if (driver.licenseExpiryDate < today) {
      return {
        success: false,
        message: `Driver license has expired on ${driver.licenseExpiryDate}! Cannot dispatch.`
      };
    }
    if (driver.status === 'Suspended') {
      return {
        success: false,
        message: `Driver is currently Suspended and cannot be assigned to any trip.`
      };
    }

    // Checking availability
    if (vehicle.status !== 'Available') {
      return { success: false, message: `Vehicle is currently ${vehicle.status} and cannot be assigned.` };
    }
    if (driver.status !== 'Available') {
      return { success: false, message: `Driver is currently ${driver.status} and cannot be assigned.` };
    }

    const trip: Trip = {
      ...newTrip,
      id: 't_' + Date.now(),
      status: 'Draft',
      createdAt: new Date().toISOString()
    };

    setTrips((prev) => [...prev, trip]);
    return { success: true, message: 'Trip draft created successfully' };
  };

  const dispatchTrip = (tripId: string) => {
    const trip = trips.find((t) => t.id === tripId);
    if (!trip) return { success: false, message: 'Trip not found.' };

    const vehicle = vehicles.find((v) => v.id === trip.vehicleId);
    const driver = drivers.find((d) => d.id === trip.driverId);

    if (!vehicle || !driver) {
      return { success: false, message: 'Assigned vehicle or driver no longer exists.' };
    }

    // Check availability at dispatch time
    if (vehicle.status !== 'Available' && vehicle.status !== 'On Trip') {
      // (If it was already dispatched, that is fine, but if it is In Shop or Retired, block it)
      return { success: false, message: `Vehicle status is ${vehicle.status}. Cannot dispatch.` };
    }
    if (driver.status !== 'Available' && driver.status !== 'On Trip') {
      return { success: false, message: `Driver status is ${driver.status}. Cannot dispatch.` };
    }

    // Enforce expiry dates on dispatch
    const today = new Date().toISOString().split('T')[0];
    if (driver.licenseExpiryDate < today) {
      return { success: false, message: `Cannot dispatch: Driver license is expired (${driver.licenseExpiryDate}).` };
    }

    // Update statuses
    setVehicles((prev) =>
      prev.map((v) => (v.id === vehicle.id ? { ...v, status: 'On Trip' as const } : v))
    );
    setDrivers((prev) =>
      prev.map((d) => (d.id === driver.id ? { ...d, status: 'On Trip' as const } : d))
    );
    setTrips((prev) =>
      prev.map((t) =>
        t.id === tripId ? { ...t, status: 'Dispatched' as const, dispatchedAt: new Date().toISOString() } : t
      )
    );

    return { success: true, message: 'Trip dispatched successfully!' };
  };

  const completeTrip = (tripId: string, finalOdometer: number, fuelConsumed: number, revenue: number) => {
    const trip = trips.find((t) => t.id === tripId);
    if (!trip) return { success: false, message: 'Trip not found.' };

    const vehicle = vehicles.find((v) => v.id === trip.vehicleId);
    if (!vehicle) return { success: false, message: 'Vehicle not found.' };

    if (finalOdometer < vehicle.odometer) {
      return {
        success: false,
        message: `Final odometer (${finalOdometer} km) cannot be less than vehicle starting odometer (${vehicle.odometer} km).`
      };
    }

    // Update vehicle odometer and return both vehicle and driver to Available
    setVehicles((prev) =>
      prev.map((v) =>
        v.id === trip.vehicleId
          ? { ...v, odometer: finalOdometer, status: 'Available' as const }
          : v
      )
    );

    setDrivers((prev) =>
      prev.map((d) =>
        d.id === trip.driverId ? { ...d, status: 'Available' as const } : d
      )
    );

    setTrips((prev) =>
      prev.map((t) =>
        t.id === tripId
          ? {
              ...t,
              status: 'Completed' as const,
              completedAt: new Date().toISOString(),
              finalOdometer,
              fuelConsumed,
              revenue
            }
          : t
      )
    );

    // Auto-record a fuel log for analytics tracking if fuel was consumed
    if (fuelConsumed > 0) {
      const fuelCost = fuelConsumed * 1.6; // estimate average price per liter
      addFuelLog({
        vehicleId: trip.vehicleId,
        liters: fuelConsumed,
        cost: Number(fuelCost.toFixed(2)),
        date: new Date().toISOString().split('T')[0]
      });
    }

    return { success: true, message: 'Trip completed successfully! Vehicle and driver are now Available.' };
  };

  const cancelTrip = (tripId: string) => {
    const trip = trips.find((t) => t.id === tripId);
    if (!trip) return { success: false, message: 'Trip not found.' };

    // Restore vehicle and driver to Available if canceled from Dispatched state
    if (trip.status === 'Dispatched') {
      setVehicles((prev) =>
        prev.map((v) => (v.id === trip.vehicleId ? { ...v, status: 'Available' as const } : v))
      );
      setDrivers((prev) =>
        prev.map((d) => (d.id === trip.driverId ? { ...d, status: 'Available' as const } : d))
      );
    }

    setTrips((prev) =>
      prev.map((t) => (t.id === tripId ? { ...t, status: 'Cancelled' as const } : t))
    );

    return { success: true, message: 'Trip cancelled successfully.' };
  };

  // --- MAINTENANCE ACTIONS ---
  const addMaintenanceLog = (newLog: Omit<MaintenanceLog, 'id' | 'status'>) => {
    const log: MaintenanceLog = {
      ...newLog,
      id: 'm_' + Date.now(),
      status: 'Active'
    };

    // Auto switch vehicle to "In Shop"
    setVehicles((prev) =>
      prev.map((v) => (v.id === newLog.vehicleId ? { ...v, status: 'In Shop' as const } : v))
    );

    // If driver was assigning to this vehicle on active trips, or other states, handled.
    setMaintenanceLogs((prev) => [...prev, log]);

    // Also auto-add to operational expenses as a Maintenance expense
    addExpense({
      vehicleId: newLog.vehicleId,
      category: 'Other',
      cost: newLog.cost,
      date: newLog.startDate,
      description: `Maintenance: ${newLog.description}`
    });

    return { success: true, message: 'Vehicle sent to shop and maintenance log opened.' };
  };

  const closeMaintenanceLog = (logId: string, closingCost?: number) => {
    const log = maintenanceLogs.find((l) => l.id === logId);
    if (!log) return { success: false, message: 'Log not found.' };

    const updatedCost = closingCost !== undefined ? closingCost : log.cost;

    setMaintenanceLogs((prev) =>
      prev.map((l) =>
        l.id === logId
          ? {
              ...l,
              status: 'Closed' as const,
              endDate: new Date().toISOString().split('T')[0],
              cost: updatedCost
            }
          : l
      )
    );

    // Restore vehicle to Available (unless retired)
    setVehicles((prev) =>
      prev.map((v) => {
        if (v.id === log.vehicleId) {
          return {
            ...v,
            status: v.status === 'Retired' ? ('Retired' as const) : ('Available' as const)
          };
        }
        return v;
      })
    );

    return { success: true, message: 'Maintenance record completed. Vehicle is now Available.' };
  };

  // --- FUEL & EXPENSE ACTIONS ---
  const addFuelLog = (newFuel: Omit<FuelLog, 'id'>) => {
    const log: FuelLog = {
      ...newFuel,
      id: 'f_' + Date.now()
    };
    setFuelLogs((prev) => [...prev, log]);
    return { success: true, message: 'Fuel refuel logged successfully.' };
  };

  const addExpense = (newExp: Omit<Expense, 'id'>) => {
    const exp: Expense = {
      ...newExp,
      id: 'e_' + Date.now()
    };
    setExpenses((prev) => [...prev, exp]);
    return { success: true, message: 'Expense recorded successfully.' };
  };

  return (
    <TransitContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        availableRoles,
        switchRole,
        logout,
        vehicles,
        drivers,
        trips,
        maintenanceLogs,
        fuelLogs,
        expenses,
        addVehicle,
        updateVehicle,
        deleteVehicle,
        addDriver,
        updateDriver,
        deleteDriver,
        addTrip,
        dispatchTrip,
        completeTrip,
        cancelTrip,
        addMaintenanceLog,
        closeMaintenanceLog,
        addFuelLog,
        addExpense,
        darkMode,
        toggleDarkMode,
        isOffline,
        setIsOffline,
        resetToDefault
      }}
    >
      {children}
    </TransitContext.Provider>
  );
};

export const useTransit = () => {
  const context = useContext(TransitContext);
  if (context === undefined) {
    throw new Error('useTransit must be used within a TransitProvider');
  }
  return context;
};
