/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useTransit } from '../context/TransitContext';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line
} from 'recharts';
import { Download, Printer, TrendingUp, DollarSign, Fuel, BarChart3, AlertCircle } from 'lucide-react';

export const Reports: React.FC = () => {
  const { vehicles, trips, maintenanceLogs, fuelLogs, expenses, currentUser } = useTransit();

  const isAuthorized = currentUser?.role === 'Financial Analyst' || currentUser?.role === 'Fleet Manager';

  // Calculations for Reports
  const reportData = vehicles.map((v) => {
    // 1. Total Completed Trips and Revenue
    const completedTrips = trips.filter((t) => t.vehicleId === v.id && t.status === 'Completed');
    const totalDistance = completedTrips.reduce((sum, t) => sum + t.plannedDistance, 0);
    const totalRevenue = completedTrips.reduce((sum, t) => sum + (t.revenue || 0), 0);

    // 2. Maintenance costs
    const maintenanceCost = maintenanceLogs
      .filter((m) => m.vehicleId === v.id)
      .reduce((sum, m) => sum + m.cost, 0);

    // 3. Fuel costs and liters
    const fuelLiters = fuelLogs
      .filter((f) => f.vehicleId === v.id)
      .reduce((sum, f) => sum + f.liters, 0);
    const fuelCost = fuelLogs
      .filter((f) => f.vehicleId === v.id)
      .reduce((sum, f) => sum + f.cost, 0);

    // 4. Other expenses (Tolls, etc)
    const otherCost = expenses
      .filter((e) => e.vehicleId === v.id)
      .reduce((sum, e) => sum + e.cost, 0);

    // Total expenses (Maintenance + Fuel + Other)
    const totalOperationalCost = maintenanceCost + fuelCost + otherCost;

    // Fuel Efficiency = Total Distance / Total Fuel Liters
    const fuelEfficiency = fuelLiters > 0 ? Number((totalDistance / fuelLiters).toFixed(2)) : 0;

    // Vehicle ROI = (Revenue - (Maintenance + Fuel)) / Acquisition Cost
    // Express as percentage
    const roiNumerator = totalRevenue - (maintenanceCost + fuelCost);
    const roiPercentage = v.acquisitionCost > 0
      ? Number(((roiNumerator / v.acquisitionCost) * 100).toFixed(2))
      : 0;

    return {
      id: v.id,
      name: v.name,
      regNumber: v.registrationNumber,
      acquisitionCost: v.acquisitionCost,
      totalRevenue,
      maintenanceCost,
      fuelCost,
      otherCost,
      totalOperationalCost,
      fuelEfficiency,
      roiPercentage,
      totalDistance
    };
  });

  // Colors for Recharts
  const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#3b82f6', '#ec4899', '#8b5cf6'];

  // CSV Export Handler
  const handleCSVExport = () => {
    let csvContent = 'data:text/csv;charset=utf-8,';
    csvContent += 'Vehicle Name,Registration,Acquisition Cost,Total Revenue,Maintenance Cost,Fuel Cost,Other Expenses,Total Operational Cost,Fuel Efficiency (km/L),ROI (%)\n';

    reportData.forEach((row) => {
      csvContent += `"${row.name}","${row.regNumber}",${row.acquisitionCost},${row.totalRevenue},${row.maintenanceCost},${row.fuelCost},${row.otherCost},${row.totalOperationalCost},${row.fuelEfficiency},${row.roiPercentage}%\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `TransitOps_Fleet_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // PDF / Print Handler
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      
      {/* RBAC Warning Banner */}
      {!isAuthorized && (
        <div id="rbac-warning-report" className="flex items-center space-x-3 rounded-xl bg-purple-500/10 p-4 border border-purple-500/30 text-purple-750 dark:text-purple-400">
          <AlertCircle className="h-5 w-5 shrink-0 text-purple-500" />
          <div className="text-xs font-semibold">
            <span className="font-bold">Role Restriction:</span> Only users with the <span className="font-bold underline text-purple-600 dark:text-purple-400">Financial Analyst</span> or <span className="font-bold underline text-purple-600 dark:text-purple-400">Fleet Manager</span> role are authorized to analyze ROI metrics and export reports. Current role: <span className="italic">{currentUser?.role}</span>.
          </div>
        </div>
      )}

      {/* Header section with print & download actions */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="font-display text-xl font-bold tracking-tight text-gray-900 dark:text-zinc-50">
            Reports & Operational Intelligence
          </h2>
          <p className="text-xs text-gray-500 dark:text-zinc-400">
            Real-time calculations of Fuel Efficiency, Operational Costs, and Fleet Asset return on investment (ROI).
          </p>
        </div>

        <div className="flex space-x-2">
          <button
            onClick={handlePrint}
            id="btn-print-report"
            className="flex items-center justify-center space-x-2 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 px-4 py-2.5 text-xs font-bold text-gray-700 shadow-xs transition-all dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800/80"
          >
            <Printer className="h-4 w-4 text-gray-400" />
            <span>Print Report</span>
          </button>
          <button
            onClick={handleCSVExport}
            id="btn-export-csv"
            className="flex items-center justify-center space-x-2 rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-bold text-white shadow-md transition-all hover:bg-indigo-700 active:scale-95"
          >
            <Download className="h-4 w-4" />
            <span>Export CSV Ledger</span>
          </button>
        </div>
      </div>

      {/* Grid summarizing Financial KPIs */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        
        {/* KPI: Total Fleet Value */}
        <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
          <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">Total Fleet Valuation</p>
          <p className="mt-2 text-2xl font-display font-bold text-gray-950 dark:text-zinc-50 font-mono">
            ${vehicles.reduce((sum, v) => sum + v.acquisitionCost, 0).toLocaleString()}
          </p>
          <p className="mt-1 text-[10px] text-gray-500">Capital expense of all registered vehicles</p>
        </div>

        {/* KPI: Total Fleet Operational Costs */}
        <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
          <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">Accumulated Op Costs</p>
          <p className="mt-2 text-2xl font-display font-bold text-gray-950 dark:text-zinc-50 font-mono text-indigo-500">
            ${reportData.reduce((sum, r) => sum + r.totalOperationalCost, 0).toLocaleString()}
          </p>
          <p className="mt-1 text-[10px] text-gray-500">Fuel + Maintenance + Toll expenses</p>
        </div>

        {/* KPI: Total Fleet Revenue */}
        <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm dark:border-zinc-800 dark:bg-zinc-900 md:col-span-2 lg:col-span-1">
          <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">Completed Route Revenue</p>
          <p className="mt-2 text-2xl font-display font-bold text-gray-950 dark:text-zinc-50 font-mono text-emerald-500">
            ${reportData.reduce((sum, r) => sum + r.totalRevenue, 0).toLocaleString()}
          </p>
          <p className="mt-1 text-[10px] text-gray-500">Total settled transport revenue</p>
        </div>

      </div>

      {/* Visual Analytics charts (High fidelity Recharts!) */}
      <div className="grid gap-6 md:grid-cols-2">
        
        {/* Chart 1: Vehicle Operational Cost Breakdown */}
        <div className="rounded-2xl border border-gray-200 bg-white p-5 shadow-xs dark:border-zinc-800 dark:bg-zinc-900">
          <h3 className="font-display font-bold text-sm text-gray-900 dark:text-zinc-100 flex items-center gap-1.5 mb-4">
            <BarChart3 className="h-4 w-4 text-indigo-500" />
            Operational Cost Breakdown per Vehicle ($)
          </h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={reportData}
                margin={{ top: 10, right: 10, left: -20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#e4e4e7" className="dark:stroke-zinc-800" />
                <XAxis dataKey="name" stroke="#a1a1aa" fontSize={10} />
                <YAxis stroke="#a1a1aa" fontSize={10} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#18181b', border: 'none', borderRadius: '8px' }}
                  labelStyle={{ color: '#fafafa', fontSize: '11px', fontWeight: 'bold' }}
                />
                <Legend wrapperStyle={{ fontSize: '10px' }} />
                <Bar dataKey="maintenanceCost" name="Maintenance" fill="#f59e0b" stackId="a" />
                <Bar dataKey="fuelCost" name="Fuel" fill="#06b6d4" stackId="a" />
                <Bar dataKey="otherCost" name="Other/Tolls" fill="#6366f1" stackId="a" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Vehicle Return on Investment (ROI) */}
        <div className="rounded-2xl border border-gray-200 bg-white p-5 shadow-xs dark:border-zinc-800 dark:bg-zinc-900">
          <h3 className="font-display font-bold text-sm text-gray-900 dark:text-zinc-100 flex items-center gap-1.5 mb-4">
            <TrendingUp className="h-4 w-4 text-emerald-500" />
            Vehicle Return on Investment (ROI %)
          </h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={reportData}
                margin={{ top: 10, right: 10, left: -20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#e4e4e7" className="dark:stroke-zinc-800" />
                <XAxis dataKey="name" stroke="#a1a1aa" fontSize={10} />
                <YAxis stroke="#a1a1aa" fontSize={10} unit="%" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#18181b', border: 'none', borderRadius: '8px' }}
                  labelStyle={{ color: '#fafafa', fontSize: '11px', fontWeight: 'bold' }}
                />
                <Bar dataKey="roiPercentage" name="ROI %">
                  {reportData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.roiPercentage >= 0 ? '#10b981' : '#f43f5e'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 3: Fuel Efficiency (Distance per Unit Fuel) */}
        <div className="rounded-2xl border border-gray-200 bg-white p-5 shadow-xs dark:border-zinc-800 dark:bg-zinc-900">
          <h3 className="font-display font-bold text-sm text-gray-900 dark:text-zinc-100 flex items-center gap-1.5 mb-4">
            <Fuel className="h-4 w-4 text-cyan-500" />
            Vehicle Fuel Efficiency (km / Liter)
          </h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={reportData}
                margin={{ top: 10, right: 15, left: -20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#e4e4e7" className="dark:stroke-zinc-800" />
                <XAxis dataKey="name" stroke="#a1a1aa" fontSize={10} />
                <YAxis stroke="#a1a1aa" fontSize={10} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#18181b', border: 'none', borderRadius: '8px' }}
                  labelStyle={{ color: '#fafafa', fontSize: '11px', fontWeight: 'bold' }}
                />
                <Line type="monotone" dataKey="fuelEfficiency" name="Efficiency (km/L)" stroke="#06b6d4" strokeWidth={3} activeDot={{ r: 8 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Table summarizing core calculations for quick scannability */}
        <div className="rounded-2xl border border-gray-200 bg-white p-5 shadow-xs dark:border-zinc-800 dark:bg-zinc-900">
          <h3 className="font-display font-bold text-sm text-gray-900 dark:text-zinc-100 mb-4">
            Fleet Efficiency & ROI Index
          </h3>
          <div className="overflow-y-auto max-h-64 space-y-3">
            {reportData.map((row) => (
              <div key={row.id} className="flex justify-between items-center border-b border-gray-100 pb-2.5 dark:border-zinc-800">
                <div>
                  <p className="text-xs font-bold text-gray-900 dark:text-zinc-100">{row.name}</p>
                  <p className="text-[10px] text-gray-400">Total Distance: {row.totalDistance.toLocaleString()} km</p>
                </div>
                <div className="text-right">
                  <p className="text-xs font-mono font-bold text-gray-900 dark:text-zinc-100">
                    {row.fuelEfficiency} km/L
                  </p>
                  <p className={`text-[10px] font-bold ${row.roiPercentage >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                    ROI: {row.roiPercentage}%
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
