/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useTransit } from '../context/TransitContext';
import {
  DollarSign,
  Plus,
  Droplet,
  FileText,
  ShieldAlert,
  X,
  TrendingDown,
  AlertCircle,
  CheckCircle,
  Calculator,
  Calendar
} from 'lucide-react';
import { ExpenseCategory } from '../types';

export const FuelExpenses: React.FC = () => {
  const {
    vehicles,
    fuelLogs,
    expenses,
    addFuelLog,
    addExpense,
    currentUser,
    maintenanceLogs
  } = useTransit();

  // Dialog State
  const [activeForm, setActiveForm] = useState<'fuel' | 'expense' | null>(null);

  // Fuel Form state
  const [fuelVehicleId, setFuelVehicleId] = useState('');
  const [liters, setLiters] = useState<number>(50);
  const [fuelCost, setFuelCost] = useState<number>(80);
  const [fuelDate, setFuelDate] = useState(new Date().toISOString().split('T')[0]);

  // Expense Form state
  const [expVehicleId, setExpVehicleId] = useState('');
  const [expCategory, setExpCategory] = useState<ExpenseCategory>('Tolls');
  const [expCost, setExpCost] = useState<number>(20);
  const [expDate, setExpDate] = useState(new Date().toISOString().split('T')[0]);
  const [description, setDescription] = useState('');

  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const isAnalyst = currentUser?.role === 'Financial Analyst' || currentUser?.role === 'Fleet Manager';

  const handleOpenFuel = () => {
    setFuelVehicleId(vehicles[0]?.id || '');
    setLiters(50);
    setFuelCost(80);
    setFuelDate(new Date().toISOString().split('T')[0]);
    setErrorMessage(null);
    setSuccessMessage(null);
    setActiveForm('fuel');
  };

  const handleOpenExpense = () => {
    setExpVehicleId(vehicles[0]?.id || '');
    setExpCategory('Tolls');
    setExpCost(20);
    setExpDate(new Date().toISOString().split('T')[0]);
    setDescription('');
    setErrorMessage(null);
    setSuccessMessage(null);
    setActiveForm('expense');
  };

  const handleSubmitFuel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAnalyst) {
      setErrorMessage('Access Denied: Financial Analyst permission required.');
      return;
    }
    if (!fuelVehicleId || liters <= 0 || fuelCost <= 0) {
      setErrorMessage('Please enter valid positive liters and cost.');
      return;
    }

    const res = addFuelLog({
      vehicleId: fuelVehicleId,
      liters,
      cost: fuelCost,
      date: fuelDate
    });

    if (res.success) {
      setSuccessMessage('Fuel log entered successfully!');
      setTimeout(() => setActiveForm(null), 1000);
    } else {
      setErrorMessage(res.message);
    }
  };

  const handleSubmitExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAnalyst) {
      setErrorMessage('Access Denied: Financial Analyst permission required.');
      return;
    }
    if (!expVehicleId || expCost <= 0 || !description) {
      setErrorMessage('Please fill in description and cost.');
      return;
    }

    const res = addExpense({
      vehicleId: expVehicleId,
      category: expCategory,
      cost: expCost,
      date: expDate,
      description
    });

    if (res.success) {
      setSuccessMessage('Operational expense registered successfully!');
      setTimeout(() => setActiveForm(null), 1000);
    } else {
      setErrorMessage(res.message);
    }
  };

  // Automatically compute total operational cost (Fuel + Maintenance + Tolls etc.) per vehicle
  const getVehicleOperationalSummary = () => {
    return vehicles.map((v) => {
      // Calculate Maintenance Cost (from closed or active logs)
      const maintenanceTotal = maintenanceLogs
        .filter((m) => m.vehicleId === v.id)
        .reduce((sum, item) => sum + item.cost, 0);

      // Calculate Fuel Cost
      const fuelTotal = fuelLogs
        .filter((f) => f.vehicleId === v.id)
        .reduce((sum, item) => sum + item.cost, 0);

      // Calculate Other Expenses (Tolls, etc.)
      const otherTotal = expenses
        .filter((e) => e.vehicleId === v.id)
        .reduce((sum, item) => sum + item.cost, 0);

      const totalOpCost = maintenanceTotal + fuelTotal + otherTotal;

      return {
        ...v,
        maintenanceTotal,
        fuelTotal,
        otherTotal,
        totalOpCost
      };
    });
  };

  const operationalSummaries = getVehicleOperationalSummary();

  return (
    <div className="space-y-6">
      
      {/* RBAC Warning banner */}
      {!isAnalyst && (
        <div id="rbac-warning-expense" className="flex items-center space-x-3 rounded-xl bg-purple-500/10 p-4 border border-purple-500/30 text-purple-750 dark:text-purple-400">
          <ShieldAlert className="h-5 w-5 shrink-0 text-purple-500" />
          <div className="text-xs font-semibold">
            <span className="font-bold">Role Restriction:</span> Only users with the <span className="font-bold underline text-purple-600 dark:text-purple-400">Financial Analyst</span> or <span className="font-bold underline text-purple-600 dark:text-purple-400">Fleet Manager</span> role can submit financial logs or verify operational expenses. Current role: <span className="italic">{currentUser?.role}</span>.
          </div>
        </div>
      )}

      {/* Header and trigger buttons */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="font-display text-xl font-bold tracking-tight text-gray-900 dark:text-zinc-50">
            Fuel & Operational Expense Ledger
          </h2>
          <p className="text-xs text-gray-500 dark:text-zinc-400">
            Log fuel purchases, specify accessory expenses, and analyze total operational cost calculations.
          </p>
        </div>

        {isAnalyst && (
          <div className="flex space-x-2">
            <button
              onClick={handleOpenFuel}
              id="btn-log-fuel"
              className="flex items-center justify-center space-x-2 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 px-4 py-2.5 text-xs font-bold text-gray-700 shadow-xs transition-all dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800/80"
            >
              <Droplet className="h-4 w-4 text-sky-500" />
              <span>Log Fuel Refuel</span>
            </button>
            <button
              onClick={handleOpenExpense}
              id="btn-record-expense"
              className="flex items-center justify-center space-x-2 rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-bold text-white shadow-md transition-all hover:bg-indigo-700 active:scale-95"
            >
              <Plus className="h-4 w-4" />
              <span>Record Toll / Expense</span>
            </button>
          </div>
        )}
      </div>

      {/* Grid summarizing Operational Cost per Vehicle */}
      <div className="grid gap-6 lg:grid-cols-3">
        
        {/* Ledger table columns */}
        <div className="lg:col-span-2 space-y-6">
          <div className="rounded-2xl border border-gray-200 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900 overflow-hidden">
            <div className="border-b border-gray-100 p-5 dark:border-zinc-800">
              <h3 className="font-display font-bold text-gray-900 dark:text-zinc-50 flex items-center gap-1.5 text-sm">
                <Calculator className="h-4 w-4 text-indigo-500" />
                Operational Cost breakdown per Vehicle
              </h3>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-left text-sm text-gray-500 dark:text-zinc-400">
                <thead className="bg-gray-50 text-xs font-bold uppercase text-gray-700 dark:bg-zinc-800/50 dark:text-zinc-300">
                  <tr>
                    <th className="px-6 py-4">Vehicle Identity</th>
                    <th className="px-6 py-4 text-right">Maintenance Cost</th>
                    <th className="px-6 py-4 text-right">Fuel Cost</th>
                    <th className="px-6 py-4 text-right">Other Expenses</th>
                    <th className="px-6 py-4 text-right bg-indigo-50/20 dark:bg-zinc-850/20 text-indigo-700 dark:text-indigo-400">Total Operational</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 border-t border-gray-100 dark:divide-zinc-800 dark:border-zinc-800">
                  {operationalSummaries.map((summary) => (
                    <tr key={summary.id} className="hover:bg-gray-50/50 dark:hover:bg-zinc-800/30">
                      <td className="px-6 py-4">
                        <div>
                          <p className="font-bold text-gray-900 dark:text-zinc-100">{summary.name}</p>
                          <p className="font-mono text-[10px] text-gray-400">{summary.registrationNumber}</p>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right font-mono font-medium">${summary.maintenanceTotal.toLocaleString()}</td>
                      <td className="px-6 py-4 text-right font-mono font-medium">${summary.fuelTotal.toLocaleString()}</td>
                      <td className="px-6 py-4 text-right font-mono font-medium">${summary.otherTotal.toLocaleString()}</td>
                      <td className="px-6 py-4 text-right font-mono font-bold text-indigo-600 bg-indigo-50/10 dark:bg-zinc-850/10 dark:text-indigo-400">
                        ${summary.totalOpCost.toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Real-time mini journal feed of the last expense events */}
        <div className="space-y-6">
          <div className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
            <h3 className="font-display font-bold text-gray-900 dark:text-zinc-50 text-sm mb-4">
              Recent Expense Log entries
            </h3>
            <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
              {expenses.map((e) => {
                const veh = vehicles.find((v) => v.id === e.vehicleId);
                return (
                  <div key={e.id} className="border border-gray-100 p-3 rounded-xl dark:border-zinc-800 bg-gray-50/20">
                    <div className="flex justify-between items-start">
                      <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded dark:bg-indigo-950/40 dark:text-indigo-400">
                        {e.category}
                      </span>
                      <span className="font-mono text-xs font-bold text-gray-900 dark:text-zinc-50">
                        -${e.cost}
                      </span>
                    </div>
                    <p className="text-xs text-gray-750 dark:text-zinc-300 mt-2 font-medium">{e.description}</p>
                    <div className="flex justify-between text-[10px] text-gray-450 mt-2">
                      <span>{veh?.name || 'Retired vehicle'}</span>
                      <span className="flex items-center gap-0.5">
                        <Calendar className="h-3 w-3" />
                        {e.date}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

      </div>

      {/* Log Fuel Dialog Modal */}
      {activeForm === 'fuel' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-sm overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-2xl dark:border-zinc-800 dark:bg-zinc-950">
            <div className="border-b border-gray-100 px-6 py-4 flex items-center justify-between dark:border-zinc-800">
              <div className="flex items-center space-x-2 text-sky-500">
                <Droplet className="h-5 w-5" />
                <h3 className="font-display font-bold text-gray-900 dark:text-zinc-50">
                  Log Fuel Purchase
                </h3>
              </div>
              <button onClick={() => setActiveForm(null)} className="p-1 rounded-lg text-gray-400 hover:bg-gray-100 dark:hover:bg-zinc-900">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitFuel} className="p-6 space-y-4">
              {errorMessage && (
                <div className="flex items-center space-x-2 text-rose-600 bg-rose-50/50 p-3 rounded-lg text-xs font-semibold border border-rose-100 dark:bg-rose-950/15">
                  <AlertCircle className="h-4 w-4" />
                  <span>{errorMessage}</span>
                </div>
              )}
              {successMessage && (
                <div className="flex items-center space-x-2 text-emerald-600 bg-emerald-50/50 p-3 rounded-lg text-xs font-semibold border border-emerald-100 dark:bg-emerald-950/15">
                  <CheckCircle className="h-4 w-4" />
                  <span>{successMessage}</span>
                </div>
              )}

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">
                    Select Vehicle
                  </label>
                  <select
                    value={fuelVehicleId}
                    onChange={(e) => setFuelVehicleId(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                  >
                    {vehicles.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.name} ({v.registrationNumber})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">
                      Liters Purchased
                    </label>
                    <input
                      type="number"
                      required
                      min="1"
                      value={liters}
                      onChange={(e) => setLiters(Number(e.target.value))}
                      className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">
                      Total Cost ($)
                    </label>
                    <input
                      type="number"
                      required
                      min="1"
                      value={fuelCost}
                      onChange={(e) => setFuelCost(Number(e.target.value))}
                      className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">
                    Refuel Date
                  </label>
                  <input
                    type="date"
                    required
                    value={fuelDate}
                    onChange={(e) => setFuelDate(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                  />
                </div>
              </div>

              <div className="border-t border-gray-100 pt-4 flex justify-end space-x-2 dark:border-zinc-800">
                <button
                  type="button"
                  onClick={() => setActiveForm(null)}
                  className="rounded-lg border border-gray-200 px-4 py-2 text-xs font-semibold text-gray-500 hover:bg-gray-50 dark:border-zinc-800 dark:text-zinc-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-sky-600 hover:bg-sky-700 px-4 py-2 text-xs font-bold text-white shadow-md"
                >
                  Record Refuel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Record Expense Dialog Modal */}
      {activeForm === 'expense' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-sm overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-2xl dark:border-zinc-800 dark:bg-zinc-950">
            <div className="border-b border-gray-100 px-6 py-4 flex items-center justify-between dark:border-zinc-800">
              <div className="flex items-center space-x-2 text-indigo-650 dark:text-indigo-400">
                <FileText className="h-5 w-5" />
                <h3 className="font-display font-bold text-gray-900 dark:text-zinc-50">
                  Record Toll / Expense
                </h3>
              </div>
              <button onClick={() => setActiveForm(null)} className="p-1 rounded-lg text-gray-400 hover:bg-gray-100 dark:hover:bg-zinc-900">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitExpense} className="p-6 space-y-4">
              {errorMessage && (
                <div className="flex items-center space-x-2 text-rose-600 bg-rose-50/50 p-3 rounded-lg text-xs font-semibold border border-rose-100 dark:bg-rose-950/15">
                  <AlertCircle className="h-4 w-4" />
                  <span>{errorMessage}</span>
                </div>
              )}
              {successMessage && (
                <div className="flex items-center space-x-2 text-emerald-600 bg-emerald-50/50 p-3 rounded-lg text-xs font-semibold border border-emerald-100 dark:bg-emerald-950/15">
                  <CheckCircle className="h-4 w-4" />
                  <span>{successMessage}</span>
                </div>
              )}

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">
                    Select Vehicle
                  </label>
                  <select
                    value={expVehicleId}
                    onChange={(e) => setExpVehicleId(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                  >
                    {vehicles.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.name} ({v.registrationNumber})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">
                      Expense Category
                    </label>
                    <select
                      value={expCategory}
                      onChange={(e) => setExpCategory(e.target.value as ExpenseCategory)}
                      className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                    >
                      <option value="Tolls">Tolls / Road Tax</option>
                      <option value="Insurance">Asset Insurance</option>
                      <option value="Permits">Transit Permits</option>
                      <option value="Driver Payout">Driver Payout</option>
                      <option value="Other">Other Ancillary</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">
                      Expense Amount ($)
                    </label>
                    <input
                      type="number"
                      required
                      min="1"
                      value={expCost}
                      onChange={(e) => setExpCost(Number(e.target.value))}
                      className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">
                    Expense Date
                  </label>
                  <input
                    type="date"
                    required
                    value={expDate}
                    onChange={(e) => setExpDate(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">
                    Description
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Interstate highway toll passage"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                  />
                </div>
              </div>

              <div className="border-t border-gray-100 pt-4 flex justify-end space-x-2 dark:border-zinc-800">
                <button
                  type="button"
                  onClick={() => setActiveForm(null)}
                  className="rounded-lg border border-gray-200 px-4 py-2 text-xs font-semibold text-gray-500 hover:bg-gray-50 dark:border-zinc-800 dark:text-zinc-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-indigo-600 hover:bg-indigo-700 px-4 py-2 text-xs font-bold text-white shadow-md"
                >
                  Log Expense
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
