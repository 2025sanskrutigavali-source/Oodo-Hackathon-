/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useTransit } from '../context/TransitContext';
import {
  Navigation,
  Plus,
  Compass,
  MapPin,
  Scale,
  Calendar,
  AlertTriangle,
  CheckCircle,
  X,
  Play,
  Check,
  Ban,
  ArrowRight,
  Gauge,
  Droplet
} from 'lucide-react';
import { Trip, TripStatus } from '../types';

export const TripManagement: React.FC = () => {
  const {
    trips,
    vehicles,
    drivers,
    addTrip,
    dispatchTrip,
    completeTrip,
    cancelTrip,
    currentUser
  } = useTransit();

  // Create Trip Drawer/Modal State
  const [isOpen, setIsOpen] = useState(false);
  const [source, setSource] = useState('');
  const [destination, setDestination] = useState('');
  const [selectedVehicleId, setSelectedVehicleId] = useState('');
  const [selectedDriverId, setSelectedDriverId] = useState('');
  const [cargoWeight, setCargoWeight] = useState<number>(0);
  const [plannedDistance, setPlannedDistance] = useState<number>(0);
  const [estimatedRevenue, setEstimatedRevenue] = useState<number>(1000);

  const [formError, setFormError] = useState<string | null>(null);
  const [formSuccess, setFormSuccess] = useState<string | null>(null);

  // Complete Trip Dialog State
  const [completeId, setCompleteId] = useState<string | null>(null);
  const [finalOdometer, setFinalOdometer] = useState<number>(0);
  const [fuelConsumed, setFuelConsumed] = useState<number>(0);
  const [tripRevenue, setTripRevenue] = useState<number>(0);
  const [completeError, setCompleteError] = useState<string | null>(null);

  // Filters for Trip Status
  const [statusFilter, setStatusFilter] = useState<string>('All');

  // Enforcing RBAC: Driver and Fleet Manager can manage trips as per OCR target users:
  // "Driver: Creates trips, assigns vehicles and drivers, and monitors active deliveries."
  // Wait, let's allow "Fleet Manager" and "Driver" roles to interact with trips.
  const isAuthorized = currentUser?.role === 'Driver' || currentUser?.role === 'Fleet Manager';

  // Available vehicles for selection (enforces rule: Retired or In Shop or already On Trip must never appear)
  const eligibleVehicles = vehicles.filter(
    (v) => v.status === 'Available'
  );

  // Available drivers for selection (enforces rule: Expired CDL or Suspended or already On Trip must never appear)
  const todayStr = new Date().toISOString().split('T')[0];
  const eligibleDrivers = drivers.filter(
    (d) => d.status === 'Available' && d.licenseExpiryDate >= todayStr && d.status !== 'Suspended'
  );

  const handleOpenCreate = () => {
    setSource('');
    setDestination('');
    setSelectedVehicleId(eligibleVehicles[0]?.id || '');
    setSelectedDriverId(eligibleDrivers[0]?.id || '');
    setCargoWeight(0);
    setPlannedDistance(0);
    setEstimatedRevenue(1000);
    setFormError(null);
    setFormSuccess(null);
    setIsOpen(true);
  };

  const handleCreateTrip = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAuthorized) {
      setFormError('Access Denied: Fleet Manager or Driver permission required.');
      return;
    }

    if (!source || !destination || !selectedVehicleId || !selectedDriverId || cargoWeight <= 0 || plannedDistance <= 0) {
      setFormError('Please enter valid positive values and complete all locations.');
      return;
    }

    const res = addTrip({
      source,
      destination,
      vehicleId: selectedVehicleId,
      driverId: selectedDriverId,
      cargoWeight,
      plannedDistance,
      revenue: estimatedRevenue
    });

    if (res.success) {
      setFormSuccess('Trip draft prepared successfully!');
      setTimeout(() => {
        setIsOpen(false);
      }, 1000);
    } else {
      setFormError(res.message);
    }
  };

  const handleDispatch = (id: string) => {
    const res = dispatchTrip(id);
    if (!res.success) {
      alert(res.message);
    }
  };

  const handleOpenComplete = (t: Trip) => {
    const veh = vehicles.find((v) => v.id === t.vehicleId);
    setCompleteId(t.id);
    setFinalOdometer(veh ? veh.odometer + t.plannedDistance : 0);
    setFuelConsumed(Math.round(t.plannedDistance * 0.3)); // reasonable default (30L/100km)
    setTripRevenue(t.revenue);
    setCompleteError(null);
  };

  const handleCompleteTrip = (e: React.FormEvent) => {
    e.preventDefault();
    if (!completeId) return;

    const res = completeTrip(completeId, finalOdometer, fuelConsumed, tripRevenue);
    if (res.success) {
      setCompleteId(null);
    } else {
      setCompleteError(res.message);
    }
  };

  const handleCancel = (id: string) => {
    if (window.confirm('Are you sure you want to cancel this trip?')) {
      const res = cancelTrip(id);
      if (!res.success) {
        alert(res.message);
      }
    }
  };

  const filteredTrips = trips.filter((t) => statusFilter === 'All' || t.status === statusFilter);

  return (
    <div className="space-y-6">
      
      {/* RBAC Warning Banner */}
      {!isAuthorized && (
        <div id="rbac-warning-trip" className="flex items-center space-x-3 rounded-xl bg-cyan-500/10 p-4 border border-cyan-500/30 text-cyan-700 dark:text-cyan-400">
          <AlertTriangle className="h-5 w-5 shrink-0" />
          <div className="text-xs font-semibold">
            <span className="font-bold">Role Restriction:</span> Only users with the <span className="font-bold underline text-cyan-600 dark:text-cyan-400">Driver</span> or <span className="font-bold underline text-cyan-600 dark:text-cyan-400">Fleet Manager</span> role can dispatch deliveries, create routes, or complete trips. Current role: <span className="italic">{currentUser?.role}</span>.
          </div>
        </div>
      )}

      {/* Title block */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="font-display text-xl font-bold tracking-tight text-gray-900 dark:text-zinc-50">
            Trip Planner & Dispatch Center
          </h2>
          <p className="text-xs text-gray-500 dark:text-zinc-400">
            Design logistical routes, dispatch operators, and log completed trip telemetry.
          </p>
        </div>

        {isAuthorized && (
          <button
            onClick={handleOpenCreate}
            id="btn-new-trip"
            className="flex items-center justify-center space-x-2 rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-bold text-white shadow-md transition-all hover:bg-indigo-700 active:scale-95"
          >
            <Plus className="h-4 w-4" />
            <span>Create New Trip Draft</span>
          </button>
        )}
      </div>

      {/* Filter panel */}
      <div className="flex space-x-2 bg-gray-100 p-1 rounded-xl w-fit dark:bg-zinc-800">
        {['All', 'Draft', 'Dispatched', 'Completed', 'Cancelled'].map((status) => (
          <button
            key={status}
            onClick={() => setStatusFilter(status)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              statusFilter === status
                ? 'bg-white text-gray-900 shadow-sm dark:bg-zinc-900 dark:text-zinc-50'
                : 'text-gray-500 hover:text-gray-900 dark:text-zinc-400 dark:hover:text-zinc-100'
            }`}
          >
            {status}
          </button>
        ))}
      </div>

      {/* Active Trips Cards Grid (Highly interactive, great on mobile!) */}
      <div className="grid gap-6 md:grid-cols-2">
        {filteredTrips.length === 0 ? (
          <div className="md:col-span-2 flex flex-col items-center justify-center py-16 border border-gray-200 rounded-2xl bg-white dark:border-zinc-800 dark:bg-zinc-900 text-center">
            <Compass className="h-12 w-12 text-gray-300 dark:text-zinc-700 animate-spin-slow" />
            <p className="mt-2 text-sm text-gray-500 dark:text-zinc-400">No scheduled trips match your selected status.</p>
          </div>
        ) : (
          filteredTrips.map((t) => {
            const veh = vehicles.find((v) => v.id === t.vehicleId);
            const drv = drivers.find((d) => d.id === t.driverId);
            return (
              <div
                key={t.id}
                className="relative overflow-hidden rounded-2xl border border-gray-200 bg-white p-5 shadow-xs transition-all hover:shadow-md dark:border-zinc-800 dark:bg-zinc-900"
              >
                {/* Badge Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="font-mono text-[10px] bg-gray-100 dark:bg-zinc-800 px-2 py-0.5 rounded text-gray-500 font-bold">
                      TRIP: #{t.id.slice(-5).toUpperCase()}
                    </span>
                  </div>
                  <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                    t.status === 'Draft'
                      ? 'bg-gray-100 text-gray-800 dark:bg-zinc-850 dark:text-zinc-300'
                      : t.status === 'Dispatched'
                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/30 dark:text-amber-300'
                      : t.status === 'Completed'
                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-300'
                      : 'bg-rose-100 text-rose-800 dark:bg-rose-950/30 dark:text-rose-300'
                  }`}>
                    {t.status}
                  </span>
                </div>

                {/* Routing info */}
                <div className="mt-4 flex items-center justify-between bg-gray-50 dark:bg-zinc-800/40 p-3 rounded-xl border border-gray-100/50 dark:border-zinc-800/50">
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-4 w-4 text-emerald-500" />
                    <div>
                      <p className="text-[10px] text-gray-400 uppercase font-bold">Source</p>
                      <p className="text-xs font-bold text-gray-800 dark:text-zinc-200">{t.source}</p>
                    </div>
                  </div>
                  <ArrowRight className="h-4 w-4 text-gray-450 dark:text-zinc-650" />
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-4 w-4 text-indigo-500" />
                    <div>
                      <p className="text-[10px] text-gray-400 uppercase font-bold">Destination</p>
                      <p className="text-xs font-bold text-gray-800 dark:text-zinc-200">{t.destination}</p>
                    </div>
                  </div>
                </div>

                {/* Assignments & Spec */}
                <div className="mt-4 grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <p className="text-[10px] text-gray-400 font-bold uppercase">Assigned Asset</p>
                    <p className="font-semibold text-gray-900 dark:text-zinc-50">{veh?.name || 'Unknown'}</p>
                    <p className="text-[10px] font-mono text-gray-400">{veh?.registrationNumber}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-gray-400 font-bold uppercase">Assigned Operator</p>
                    <p className="font-semibold text-gray-900 dark:text-zinc-50">{drv?.name || 'Unknown'}</p>
                    <p className="text-[10px] text-gray-400">CDL Category: {drv?.licenseCategory}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-gray-400 font-bold uppercase">Cargo weight</p>
                    <p className="font-semibold text-gray-900 dark:text-zinc-50 flex items-center gap-1">
                      <Scale className="h-3 w-3 text-gray-400" />
                      {t.cargoWeight.toLocaleString()} kg
                    </p>
                  </div>
                  <div>
                    <p className="text-[10px] text-gray-400 font-bold uppercase">Planned Distance</p>
                    <p className="font-semibold text-gray-900 dark:text-zinc-50">
                      {t.plannedDistance} km
                    </p>
                  </div>
                </div>

                {/* Telemetry logged if completed */}
                {t.status === 'Completed' && (
                  <div className="mt-4 bg-emerald-500/10 p-3 rounded-xl border border-emerald-500/20 text-xs grid grid-cols-2 gap-2 text-emerald-800 dark:text-emerald-300 font-mono">
                    <div>
                      <span>Final Odometer: </span>
                      <span className="font-bold">{t.finalOdometer} km</span>
                    </div>
                    <div>
                      <span>Fuel Consumed: </span>
                      <span className="font-bold">{t.fuelConsumed} L</span>
                    </div>
                  </div>
                )}

                {/* Dispatch Controls (Enforcing actions based on status and roles) */}
                {isAuthorized && (
                  <div className="mt-5 border-t border-gray-150 pt-4 flex justify-end space-x-2 dark:border-zinc-800">
                    {t.status === 'Draft' && (
                      <>
                        <button
                          onClick={() => handleCancel(t.id)}
                          className="flex items-center space-x-1 px-3 py-1.5 text-xs text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/20 font-bold rounded-lg transition-colors"
                        >
                          <Ban className="h-3.5 w-3.5" />
                          <span>Cancel Trip</span>
                        </button>
                        <button
                          onClick={() => handleDispatch(t.id)}
                          className="flex items-center space-x-1.5 bg-indigo-600 text-white px-4 py-1.5 text-xs font-bold rounded-lg shadow-sm hover:bg-indigo-700 transition-colors"
                        >
                          <Play className="h-3.5 w-3.5" />
                          <span>Dispatch Trip</span>
                        </button>
                      </>
                    )}
                    {t.status === 'Dispatched' && (
                      <>
                        <button
                          onClick={() => handleCancel(t.id)}
                          className="flex items-center space-x-1 px-3 py-1.5 text-xs text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/20 font-bold rounded-lg transition-colors"
                        >
                          <Ban className="h-3.5 w-3.5" />
                          <span>Cancel Trip</span>
                        </button>
                        <button
                          onClick={() => handleOpenComplete(t)}
                          className="flex items-center space-x-1.5 bg-emerald-600 text-white px-4 py-1.5 text-xs font-bold rounded-lg shadow-sm hover:bg-emerald-700 transition-colors"
                        >
                          <Check className="h-3.5 w-3.5" />
                          <span>Log Completion</span>
                        </button>
                      </>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Prepare Trip Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-lg overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-2xl dark:border-zinc-800 dark:bg-zinc-950">
            <div className="border-b border-gray-100 px-6 py-4 flex items-center justify-between dark:border-zinc-800">
              <div className="flex items-center space-x-2 text-indigo-600 dark:text-indigo-400">
                <Navigation className="h-5 w-5" />
                <h3 className="font-display font-bold text-gray-900 dark:text-zinc-50">
                  Prepare Dispatch Request
                </h3>
              </div>
              <button onClick={() => setIsOpen(false)} className="p-1 rounded-lg text-gray-400 hover:bg-gray-100 dark:hover:bg-zinc-900">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTrip} className="p-6 space-y-4">
              {formError && (
                <div className="flex items-center space-x-2 text-rose-600 bg-rose-50/50 p-3 rounded-lg text-xs font-semibold border border-rose-100 dark:bg-rose-950/15 dark:border-rose-900/50">
                  <AlertTriangle className="h-4 w-4 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {formSuccess && (
                <div className="flex items-center space-x-2 text-emerald-600 bg-emerald-50/50 p-3 rounded-lg text-xs font-semibold border border-emerald-100 dark:bg-emerald-950/15 dark:border-emerald-900/50">
                  <CheckCircle className="h-4 w-4 shrink-0" />
                  <span>{formSuccess}</span>
                </div>
              )}

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">Source City</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Austin, TX"
                    value={source}
                    onChange={(e) => setSource(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">Destination City</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Dallas, TX"
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">Assign Available Vehicle</label>
                  <select
                    value={selectedVehicleId}
                    onChange={(e) => setSelectedVehicleId(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                  >
                    {eligibleVehicles.length === 0 ? (
                      <option value="">-- No Available Vehicles! --</option>
                    ) : (
                      eligibleVehicles.map((v) => (
                        <option key={v.id} value={v.id}>
                          {v.name} ({v.registrationNumber}) - Max: {v.maxCapacity}kg
                        </option>
                      ))
                    )}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">Assign Available Driver</label>
                  <select
                    value={selectedDriverId}
                    onChange={(e) => setSelectedDriverId(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                  >
                    {eligibleDrivers.length === 0 ? (
                      <option value="">-- No Available Drivers! --</option>
                    ) : (
                      eligibleDrivers.map((d) => (
                        <option key={d.id} value={d.id}>
                          {d.name} (Safety: {d.safetyScore}/100)
                        </option>
                      ))
                    )}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">Cargo Weight (kg)</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={cargoWeight}
                    onChange={(e) => setCargoWeight(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">Planned Distance (km)</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={plannedDistance}
                    onChange={(e) => setPlannedDistance(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">Expected Revenue ($)</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={estimatedRevenue}
                    onChange={(e) => setEstimatedRevenue(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                  />
                </div>
              </div>

              <div className="border-t border-gray-100 pt-4 flex justify-end space-x-2 dark:border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="rounded-lg border border-gray-200 px-4 py-2 text-xs font-semibold text-gray-500 hover:bg-gray-50 dark:border-zinc-800 dark:text-zinc-400 dark:hover:bg-zinc-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={eligibleVehicles.length === 0 || eligibleDrivers.length === 0}
                  className="rounded-lg bg-indigo-600 px-4 py-2 text-xs font-bold text-white shadow-md hover:bg-indigo-700 disabled:bg-gray-200 dark:disabled:bg-zinc-800"
                >
                  Save Draft
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Complete Trip Logging Dialog Modal */}
      {completeId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-md overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-2xl dark:border-zinc-800 dark:bg-zinc-950">
            <div className="border-b border-gray-100 px-6 py-4 flex items-center justify-between dark:border-zinc-800">
              <div className="flex items-center space-x-2 text-emerald-600 dark:text-emerald-400">
                <CheckCircle className="h-5 w-5" />
                <h3 className="font-display font-bold text-gray-900 dark:text-zinc-50">
                  Log Trip Completion
                </h3>
              </div>
              <button onClick={() => setCompleteId(null)} className="p-1 rounded-lg text-gray-400 hover:bg-gray-100 dark:hover:bg-zinc-900">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCompleteTrip} className="p-6 space-y-4">
              {completeError && (
                <div className="flex items-center space-x-2 text-rose-600 bg-rose-50/50 p-3 rounded-lg text-xs font-semibold border border-rose-100 dark:bg-rose-950/15 dark:border-rose-900/50">
                  <AlertTriangle className="h-4 w-4 shrink-0" />
                  <span>{completeError}</span>
                </div>
              )}

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">
                    Final Odometer (km)
                  </label>
                  <div className="relative flex items-center">
                    <Gauge className="absolute left-3 h-4 w-4 text-gray-450" />
                    <input
                      type="number"
                      required
                      min="0"
                      value={finalOdometer}
                      onChange={(e) => setFinalOdometer(Number(e.target.value))}
                      className="w-full rounded-lg border border-gray-200 pl-10 pr-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                    />
                  </div>
                  <p className="text-[10px] text-gray-400 mt-1">Starting Odometer: {vehicles.find((v) => v.id === trips.find((t) => t.id === completeId)?.vehicleId)?.odometer} km</p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">
                    Fuel Consumed (Liters)
                  </label>
                  <div className="relative flex items-center">
                    <Droplet className="absolute left-3 h-4 w-4 text-gray-450" />
                    <input
                      type="number"
                      required
                      min="0"
                      value={fuelConsumed}
                      onChange={(e) => setFuelConsumed(Number(e.target.value))}
                      className="w-full rounded-lg border border-gray-200 pl-10 pr-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">
                    Actual Settled Revenue ($)
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    value={tripRevenue}
                    onChange={(e) => setTripRevenue(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                  />
                </div>
              </div>

              <div className="border-t border-gray-100 pt-4 flex justify-end space-x-2 dark:border-zinc-800">
                <button
                  type="button"
                  onClick={() => setCompleteId(null)}
                  className="rounded-lg border border-gray-200 px-4 py-2 text-xs font-semibold text-gray-500 hover:bg-gray-50 dark:border-zinc-800 dark:text-zinc-400 dark:hover:bg-zinc-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-emerald-600 px-4 py-2 text-xs font-bold text-white shadow-md hover:bg-emerald-700"
                >
                  Save Telemetry & Complete
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
