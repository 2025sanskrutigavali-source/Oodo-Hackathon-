/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { TransitProvider, useTransit } from './context/TransitContext';
import { Header } from './components/Header';
import { Login } from './components/Login';
import { Dashboard } from './components/Dashboard';
import { VehicleRegistry } from './components/VehicleRegistry';
import { DriverManagement } from './components/DriverManagement';
import { TripManagement } from './components/TripManagement';
import { Maintenance } from './components/Maintenance';
import { FuelExpenses } from './components/FuelExpenses';
import { Reports } from './components/Reports';

import {
  LayoutDashboard,
  Truck,
  Users,
  Navigation,
  Wrench,
  DollarSign,
  BarChart3,
  Menu,
  X
} from 'lucide-react';

type Tab = 'dashboard' | 'vehicles' | 'drivers' | 'trips' | 'maintenance' | 'expenses' | 'reports';

const MainLayout: React.FC = () => {
  const { currentUser } = useTransit();
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  if (!currentUser) {
    return <Login />;
  }

  const tabs = [
    { id: 'dashboard' as Tab, name: 'Dashboard', icon: LayoutDashboard },
    { id: 'vehicles' as Tab, name: 'Vehicle Registry', icon: Truck },
    { id: 'drivers' as Tab, name: 'Drivers', icon: Users },
    { id: 'trips' as Tab, name: 'Trips & Dispatch', icon: Navigation },
    { id: 'maintenance' as Tab, name: 'Maintenance', icon: Wrench },
    { id: 'expenses' as Tab, name: 'Expenses & Fuel', icon: DollarSign },
    { id: 'reports' as Tab, name: 'Reports & ROI', icon: BarChart3 }
  ];

  const renderActiveComponent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'vehicles':
        return <VehicleRegistry />;
      case 'drivers':
        return <DriverManagement />;
      case 'trips':
        return <TripManagement />;
      case 'maintenance':
        return <Maintenance />;
      case 'expenses':
        return <FuelExpenses />;
      case 'reports':
        return <Reports />;
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-gradient-to-tr from-slate-50 via-indigo-50/20 to-teal-50/10 text-gray-900 transition-colors dark:from-zinc-950 dark:via-zinc-900 dark:to-zinc-950 dark:text-zinc-100 flex flex-col">
      {/* Google Flow Ambient Blurred Orbs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute -top-[15%] -left-[10%] w-[45%] h-[45%] rounded-full bg-indigo-300/15 dark:bg-indigo-600/10 blur-[130px]" />
        <div className="absolute top-[30%] -right-[10%] w-[40%] h-[40%] rounded-full bg-purple-300/15 dark:bg-purple-600/10 blur-[130px]" />
        <div className="absolute -bottom-[10%] left-[20%] w-[35%] h-[35%] rounded-full bg-emerald-200/15 dark:bg-emerald-600/5 blur-[100px]" />
      </div>

      {/* Platform Header */}
      <div className="relative z-10">
        <Header />
      </div>

      {/* Main Container - Responsive Layout */}
      <div className="relative z-10 flex-1 flex flex-col md:flex-row max-w-7xl w-full mx-auto px-4 py-6 sm:px-6 lg:px-8 gap-6">
        
        {/* Navigation Sidebar (Desktop view) */}
        <aside className="hidden md:block w-64 shrink-0">
          <nav className="space-y-1.5 sticky top-24">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-2xl text-xs font-bold transition-all ${
                    isActive
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10 border-r-4 border-indigo-400'
                      : 'text-gray-500 hover:text-gray-950 hover:bg-white/65 dark:text-zinc-400 dark:hover:text-zinc-50 dark:hover:bg-zinc-900/60'
                  }`}
                >
                  <Icon className="h-4.5 w-4.5" />
                  <span>{tab.name}</span>
                </button>
              );
            })}
          </nav>
        </aside>


        {/* Bottom Navigation / Menu Bar (Mobile Adaptive Layout for iOS and Android) */}
        <div className="md:hidden flex items-center justify-between bg-white dark:bg-zinc-900 border border-gray-150 dark:border-zinc-800 p-3 rounded-2xl shadow-sm">
          <div className="flex items-center space-x-2">
            {(() => {
              const active = tabs.find((t) => t.id === activeTab);
              const ActiveIcon = active?.icon || LayoutDashboard;
              return (
                <>
                  <ActiveIcon className="h-5 w-5 text-indigo-500" />
                  <span className="text-sm font-bold text-gray-800 dark:text-zinc-100">{active?.name}</span>
                </>
              );
            })()}
          </div>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            id="btn-mobile-menu"
            className="p-2 text-gray-500 hover:text-gray-950 dark:text-zinc-400 dark:hover:text-zinc-100"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {/* Mobile dropdown menu */}
        {mobileMenuOpen && (
          <div className="md:hidden grid grid-cols-2 gap-2 p-4 bg-white dark:bg-zinc-900 border border-gray-150 dark:border-zinc-800 rounded-2xl shadow-lg">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`flex flex-col items-center justify-center p-3 rounded-xl border transition-all text-center gap-1.5 ${
                    isActive
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                      : 'border-gray-100 dark:border-zinc-800 text-gray-500 dark:text-zinc-400 hover:bg-gray-50 dark:hover:bg-zinc-800/40'
                  }`}
                >
                  <Icon className="h-4.5 w-4.5" />
                  <span className="text-[10px] font-bold">{tab.name}</span>
                </button>
              );
            })}
          </div>
        )}

        {/* Active View Display Container */}
        <main className="flex-1 min-w-0 bg-transparent rounded-2xl">
          {renderActiveComponent()}
        </main>

      </div>

      {/* Footer metadata details */}
      <footer className="relative z-10 mt-auto border-t border-gray-200 py-6 dark:border-zinc-900 bg-white/50 dark:bg-zinc-950/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-gray-400">
          <p>© 2026 TransitOps. Smart Transport Operations Platform. Fully Compliant offline-ready architecture.</p>
          <div className="flex space-x-4">
            <span>Server: OK</span>
            <span>Local Database: Connected (Synced)</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <TransitProvider>
      <MainLayout />
    </TransitProvider>
  );
}
