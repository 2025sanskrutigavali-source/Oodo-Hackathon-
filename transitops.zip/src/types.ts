/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Role = 'Fleet Manager' | 'Driver' | 'Safety Officer' | 'Financial Analyst';

export interface User {
  email: string;
  name: string;
  role: Role;
}

export type VehicleStatus = 'Available' | 'On Trip' | 'In Shop' | 'Retired';
export type VehicleType = 'Semi-Truck' | 'Box Truck' | 'Cargo Van' | 'Flatbed' | 'EV Delivery Van';

export interface Vehicle {
  id: string;
  registrationNumber: string; // Unique
  name: string;
  type: VehicleType;
  maxCapacity: number; // in kg
  odometer: number; // in km
  acquisitionCost: number; // in USD
  status: VehicleStatus;
  region: string;
}

export type DriverStatus = 'Available' | 'On Trip' | 'Off Duty' | 'Suspended';

export interface Driver {
  id: string;
  name: string;
  licenseNumber: string;
  licenseCategory: string; // e.g., Class A CDL
  licenseExpiryDate: string; // YYYY-MM-DD
  contactNumber: string;
  safetyScore: number; // 0 to 100
  status: DriverStatus;
}

export type TripStatus = 'Draft' | 'Dispatched' | 'Completed' | 'Cancelled';

export interface Trip {
  id: string;
  source: string;
  destination: string;
  vehicleId: string;
  driverId: string;
  cargoWeight: number; // in kg
  plannedDistance: number; // in km
  status: TripStatus;
  revenue: number; // in USD, calculated or input
  createdAt: string;
  dispatchedAt?: string;
  completedAt?: string;
  finalOdometer?: number;
  fuelConsumed?: number; // in liters
}

export type MaintenanceStatus = 'Active' | 'Closed';

export interface MaintenanceLog {
  id: string;
  vehicleId: string;
  description: string;
  cost: number;
  startDate: string; // YYYY-MM-DD
  endDate?: string; // YYYY-MM-DD
  status: MaintenanceStatus;
}

export interface FuelLog {
  id: string;
  vehicleId: string;
  liters: number;
  cost: number;
  date: string;
}

export type ExpenseCategory = 'Tolls' | 'Insurance' | 'Permits' | 'Driver Payout' | 'Other';

export interface Expense {
  id: string;
  vehicleId: string;
  category: ExpenseCategory;
  cost: number;
  date: string;
  description: string;
}
