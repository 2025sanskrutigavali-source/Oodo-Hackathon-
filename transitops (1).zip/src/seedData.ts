/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Vehicle, Driver, Trip, MaintenanceLog, FuelLog, Expense } from './types';

export const SEED_VEHICLES: Vehicle[] = [
  {
    id: 'v1',
    registrationNumber: 'TX-783-TRK',
    name: 'Freightliner Cascadia',
    type: 'Semi-Truck',
    maxCapacity: 20000,
    odometer: 145200,
    acquisitionCost: 135000,
    status: 'Available',
    region: 'South'
  },
  {
    id: 'v2',
    registrationNumber: 'CA-902-VAN',
    name: 'Ford Transit 350',
    type: 'Cargo Van',
    maxCapacity: 1500,
    odometer: 48900,
    acquisitionCost: 42000,
    status: 'Available',
    region: 'West'
  },
  {
    id: 'v3',
    registrationNumber: 'NY-442-EV',
    name: 'Rivian EDV 700',
    type: 'EV Delivery Van',
    maxCapacity: 1200,
    odometer: 12400,
    acquisitionCost: 75000,
    status: 'On Trip',
    region: 'East'
  },
  {
    id: 'v4',
    registrationNumber: 'IL-115-BOX',
    name: 'Isuzu NPR-HD',
    type: 'Box Truck',
    maxCapacity: 6000,
    odometer: 89300,
    acquisitionCost: 68000,
    status: 'In Shop',
    region: 'Midwest'
  },
  {
    id: 'v5',
    registrationNumber: 'FL-889-FLT',
    name: 'Peterbilt 389',
    type: 'Flatbed',
    maxCapacity: 22000,
    odometer: 210400,
    acquisitionCost: 155000,
    status: 'Available',
    region: 'South'
  }
];

export const SEED_DRIVERS: Driver[] = [
  {
    id: 'd1',
    name: 'Amit Sharma',
    licenseNumber: 'DL-TX99823',
    licenseCategory: 'Class A CDL',
    licenseExpiryDate: '2026-12-15', // Active
    contactNumber: '+1 (512) 555-0192',
    safetyScore: 94,
    status: 'Available'
  },
  {
    id: 'd2',
    name: 'Priya Patel',
    licenseNumber: 'DL-CA45210',
    licenseCategory: 'Class C CDL',
    licenseExpiryDate: '2026-08-01', // Expiring soon
    contactNumber: '+1 (415) 555-0143',
    safetyScore: 98,
    status: 'Available'
  },
  {
    id: 'd3',
    name: 'Rajesh Kumar',
    licenseNumber: 'DL-NY77123',
    licenseCategory: 'Class A CDL',
    licenseExpiryDate: '2026-07-20', // Expiring in ~9 days from 2026-07-11!
    contactNumber: '+1 (212) 555-0187',
    safetyScore: 82,
    status: 'On Trip'
  },
  {
    id: 'd4',
    name: 'Vikram Singh',
    licenseNumber: 'DL-FL11540',
    licenseCategory: 'Class A CDL',
    licenseExpiryDate: '2025-05-10', // Expired!
    contactNumber: '+1 (305) 555-0121',
    safetyScore: 75,
    status: 'Suspended'
  },
  {
    id: 'd5',
    name: 'Ananya Iyer',
    licenseNumber: 'DL-IL89445',
    licenseCategory: 'Class B CDL',
    licenseExpiryDate: '2027-04-18', // Active
    contactNumber: '+1 (312) 555-0165',
    safetyScore: 91,
    status: 'Available'
  }
];

export const SEED_TRIPS: Trip[] = [
  {
    id: 't1',
    source: 'Austin, TX',
    destination: 'Dallas, TX',
    vehicleId: 'v1',
    driverId: 'd1',
    cargoWeight: 15000,
    plannedDistance: 310,
    status: 'Completed',
    revenue: 2450,
    createdAt: '2026-07-01T10:00:00Z',
    dispatchedAt: '2026-07-02T08:00:00Z',
    completedAt: '2026-07-02T13:30:00Z',
    finalOdometer: 145510,
    fuelConsumed: 95
  },
  {
    id: 't2',
    source: 'Los Angeles, CA',
    destination: 'San Francisco, CA',
    vehicleId: 'v2',
    driverId: 'd2',
    cargoWeight: 1200,
    plannedDistance: 615,
    status: 'Completed',
    revenue: 1100,
    createdAt: '2026-07-05T09:00:00Z',
    dispatchedAt: '2026-07-06T07:00:00Z',
    completedAt: '2026-07-06T15:45:00Z',
    finalOdometer: 49515,
    fuelConsumed: 55
  },
  {
    id: 't3',
    source: 'New York, NY',
    destination: 'Boston, MA',
    vehicleId: 'v3',
    driverId: 'd3',
    cargoWeight: 800,
    plannedDistance: 350,
    status: 'Dispatched',
    revenue: 950,
    createdAt: '2026-07-10T14:00:00Z',
    dispatchedAt: '2026-07-11T06:00:00Z'
  },
  {
    id: 't4',
    source: 'Chicago, IL',
    destination: 'Indianapolis, IN',
    vehicleId: 'v2',
    driverId: 'd5',
    cargoWeight: 1400,
    plannedDistance: 295,
    status: 'Draft',
    revenue: 750,
    createdAt: '2026-07-11T12:00:00Z'
  }
];

export const SEED_MAINTENANCE: MaintenanceLog[] = [
  {
    id: 'm1',
    vehicleId: 'v4',
    description: 'Transmission overhaul and fluid replacement',
    cost: 1450,
    startDate: '2026-07-08',
    status: 'Active'
  },
  {
    id: 'm2',
    vehicleId: 'v1',
    description: 'Scheduled lube, oil, and filter change',
    cost: 180,
    startDate: '2026-06-20',
    endDate: '2026-06-20',
    status: 'Closed'
  },
  {
    id: 'm3',
    vehicleId: 'v2',
    description: 'Front brake pads and rotors replacement',
    cost: 320,
    startDate: '2026-06-15',
    endDate: '2026-06-16',
    status: 'Closed'
  }
];

export const SEED_FUEL_LOGS: FuelLog[] = [
  {
    id: 'f1',
    vehicleId: 'v1',
    liters: 95,
    cost: 152,
    date: '2026-07-02'
  },
  {
    id: 'f2',
    vehicleId: 'v2',
    liters: 55,
    cost: 88,
    date: '2026-07-06'
  },
  {
    id: 'f3',
    vehicleId: 'v1',
    liters: 110,
    cost: 176,
    date: '2026-07-09'
  }
];

export const SEED_EXPENSES: Expense[] = [
  {
    id: 'e1',
    vehicleId: 'v1',
    category: 'Tolls',
    cost: 45,
    date: '2026-07-02',
    description: 'I-35 Texas toll roads'
  },
  {
    id: 'e2',
    vehicleId: 'v2',
    category: 'Tolls',
    cost: 25,
    date: '2026-07-06',
    description: 'Bay Bridge tolls'
  }
];
