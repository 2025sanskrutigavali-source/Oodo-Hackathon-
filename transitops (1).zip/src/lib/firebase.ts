/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  getDoc, 
  setDoc, 
  collection, 
  query, 
  where, 
  getDocs 
} from 'firebase/firestore';

// In AI Studio workspace, we have firebase-applet-config.json.
// We can use the values directly as fallback config or read from standard config.
const firebaseConfig = {
  apiKey: "AIzaSyCiKoUVGQUIiZ9sSPSNy8RK1HCrXhbZ_8E",
  authDomain: "iconic-flames-jxhgq.firebaseapp.com",
  projectId: "iconic-flames-jxhgq",
  storageBucket: "iconic-flames-jxhgq.firebasestorage.app",
  messagingSenderId: "700753477293",
  appId: "1:700753477293:web:511a9cb8d491f885d29024"
};

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
const auth = getAuth(app);
const db = getFirestore(app);
const googleProvider = new GoogleAuthProvider();

// Standardize Google login scopes if needed
googleProvider.addScope('email');
googleProvider.addScope('profile');

export {
  app,
  auth,
  db,
  googleProvider,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  doc,
  getDoc,
  setDoc,
  collection,
  query,
  where,
  getDocs
};
