/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useTransit } from '../context/TransitContext';
import {
  Truck,
  CheckCircle,
  Wrench,
  Navigation,
  Clock,
  Users,
  Percent,
  AlertTriangle,
  MapPin,
  TrendingUp,
  SlidersHorizontal,
  CloudLightning,
  Plus,
  X,
  UserPlus
} from 'lucide-react';
import { VehicleType, VehicleStatus } from '../types';

import dashboardHero from '../assets/images/dashboard_hero_1783833328704.jpg';

export const Dashboard: React.FC = () => {
  const { vehicles, drivers, trips, maintenanceLogs, currentUser, isOffline, addDriver } = useTransit();

  // Filters State
  const [selectedType, setSelectedType] = useState<string>('All');
  const [selectedRegion, setSelectedRegion] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');

  // Quick Add Driver State
  const [isDriverModalOpen, setIsDriverModalOpen] = useState(false);
  const [newDriverName, setNewDriverName] = useState('');
  const [newDriverLicense, setNewDriverLicense] = useState('');
  const [newDriverCategory, setNewDriverCategory] = useState('Class A CDL');
  const [newDriverExpiry, setNewDriverExpiry] = useState('');
  const [newDriverContact, setNewDriverContact] = useState('');
  const [newDriverSafety, setNewDriverSafety] = useState<number>(100);
  const [newDriverStatus, setNewDriverStatus] = useState<'Available' | 'On Trip' | 'Off Duty' | 'Suspended'>('Available');
  const [driverError, setDriverError] = useState<string | null>(null);
  const [driverSuccess, setDriverSuccess] = useState<string | null>(null);

  const handleQuickAddDriverSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDriverName || !newDriverLicense || !newDriverExpiry || !newDriverContact) {
      setDriverError('Please fill in all details.');
      return;
    }
    if (newDriverSafety < 0 || newDriverSafety > 100) {
      setDriverError('Safety score must be between 0 and 100.');
      return;
    }

    const res = addDriver({
      name: newDriverName,
      licenseNumber: newDriverLicense,
      licenseCategory: newDriverCategory,
      licenseExpiryDate: newDriverExpiry,
      contactNumber: newDriverContact,
      safetyScore: newDriverSafety,
      status: newDriverStatus
    });

    if (res.success) {
      setDriverSuccess('Driver registered successfully!');
      setDriverError(null);
      setTimeout(() => {
        setIsDriverModalOpen(false);
        // Reset form
        setNewDriverName('');
        setNewDriverLicense('');
        setNewDriverCategory('Class A CDL');
        setNewDriverExpiry('');
        setNewDriverContact('');
        setNewDriverSafety(100);
        setNewDriverStatus('Available');
        setDriverSuccess(null);
      }, 1000);
    } else {
      setDriverError(res.message);
    }
  };

  // Filtered lists
  const filteredVehicles = vehicles.filter((v) => {
    const matchType = selectedType === 'All' || v.type === selectedType;
    const matchRegion = selectedRegion === 'All' || v.region === selectedRegion;
    const matchStatus = selectedStatus === 'All' || v.status === selectedStatus;
    return matchType && matchRegion && matchStatus;
  });

  // KPI Calculations
  const totalVehicles = vehicles.length;
  const activeVehiclesCount = vehicles.filter((v) => v.status === 'On Trip').length;
  const availableVehiclesCount = vehicles.filter((v) => v.status === 'Available').length;
  const inMaintenanceCount = vehicles.filter((v) => v.status === 'In Shop').length;

  const activeTripsCount = trips.filter((t) => t.status === 'Dispatched').length;
  const pendingTripsCount = trips.filter((t) => t.status === 'Draft').length;
  
  const driversOnDutyCount = drivers.filter((d) => d.status === 'On Trip').length;
  const totalDrivers = drivers.length;

  const fleetUtilization = totalVehicles > 0 
    ? Math.round((activeVehiclesCount / totalVehicles) * 100) 
    : 0;

  // Additional alerts for Safety Officer and Fleet Manager
  const todayStr = new Date().toISOString().split('T')[0];
  const thirtyDaysFromNow = new Date();
  thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);
  const thirtyDaysStr = thirtyDaysFromNow.toISOString().split('T')[0];

  const expiredLicenses = drivers.filter((d) => d.licenseExpiryDate < todayStr);
  const expiringSoonLicenses = drivers.filter(
    (d) => d.licenseExpiryDate >= todayStr && d.licenseExpiryDate <= thirtyDaysStr
  );

  const activeMaintenanceCount = maintenanceLogs.filter((m) => m.status === 'Active').length;

  // Regions list
  const regions = ['All', ...Array.from(new Set(vehicles.map((v) => v.region)))];
  const vehicleTypes = ['All', 'Semi-Truck', 'Box Truck', 'Cargo Van', 'Flatbed', 'EV Delivery Van'];
  const statusTypes = ['All', 'Available', 'On Trip', 'In Shop', 'Retired'];

  return (
    <div className="space-y-6">
      
      {/* Offline Alert Banner */}
      {isOffline && (
        <div id="offline-banner" className="flex items-center space-x-3 rounded-2xl bg-amber-500/10 p-4 border border-amber-500/30 text-amber-600 dark:text-amber-400 backdrop-blur-md">
          <CloudLightning className="h-5 w-5 animate-pulse shrink-0" />
          <div className="text-sm font-medium">
            <span className="font-bold">Offline Sync Active:</span> You are currently editing offline. Changes will remain buffered in client-side secure index databases and auto-sync securely once network access resumes.
          </div>
        </div>
      )}

      {/* Google Flow Widescreen Hero Banner Section */}
      <div className="relative overflow-hidden rounded-3xl border border-white/40 dark:border-zinc-800/80 shadow-lg bg-gradient-to-r from-indigo-500/10 via-purple-500/10 to-pink-500/10 p-1">
        <div className="relative h-64 sm:h-72 w-full rounded-2xl overflow-hidden">
          <img
            src={dashboardHero}
            alt="TransitOps smart control room dashboard banner illustration, google labs flowing flow aesthetic style"
            className="w-full h-full object-cover object-center scale-105 transition-transform duration-10000 hover:scale-100"
            referrerPolicy="no-referrer"
          />
          {/* Glassmorphism gradient mask */}
          <div className="absolute inset-0 bg-gradient-to-t from-gray-950/90 via-gray-950/45 to-transparent flex flex-col justify-end p-6 sm:p-8">
            <div className="max-w-2xl bg-white/10 dark:bg-zinc-950/50 backdrop-blur-md rounded-2xl p-5 border border-white/25 shadow-xl h-[256px]">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-indigo-600 text-white shadow-md animate-pulse">
                System Active
              </span>
              <h2 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight text-white mt-3">
                Welcome Back, <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-300 via-purple-300 to-pink-300">{currentUser?.name}</span>
              </h2>
              <p id="active-role-context-text" className="text-xs sm:text-sm text-[#f8f3f3] w-[500px] h-[50px] mt-1.5 font-medium leading-relaxed overflow-hidden">
                Active Role Context: <span className="font-bold underline decoration-indigo-400 underline-offset-4 text-indigo-200">{currentUser?.role}</span> — Overseeing real-time fleet assets, routing compliance, and fuel efficiency.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* High-Fidelity Bento Grid KPIs */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        
        {/* KPI Card: Active Vehicles */}
        <div className="group relative overflow-hidden rounded-3xl border border-white/40 bg-white/70 p-6 shadow-sm transition-all hover:shadow-md dark:border-zinc-800/80 dark:bg-zinc-900/60 backdrop-blur-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase tracking-wider">Active Vehicles</span>
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 dark:bg-indigo-950/40 dark:text-indigo-400 shadow-sm">
              <Truck className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-4 flex items-baseline justify-between">
            <span className="text-3xl font-display font-bold text-gray-900 dark:text-zinc-50">{activeVehiclesCount}</span>
            <span className="text-[10px] text-gray-400 dark:text-zinc-500 font-bold">out of {totalVehicles} total</span>
          </div>
          <div className="absolute bottom-0 left-0 h-1 w-full bg-gradient-to-r from-indigo-500 to-purple-500 opacity-80 group-hover:h-1.5 transition-all" />
        </div>

        {/* KPI Card: Available Vehicles */}
        <div className="group relative overflow-hidden rounded-3xl border border-white/40 bg-white/70 p-6 shadow-sm transition-all hover:shadow-md dark:border-zinc-800/80 dark:bg-zinc-900/60 backdrop-blur-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase tracking-wider">Available Fleet</span>
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400 shadow-sm">
              <CheckCircle className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-4 flex items-baseline justify-between">
            <span className="text-3xl font-display font-bold text-gray-900 dark:text-zinc-50">{availableVehiclesCount}</span>
            <span className="text-[10px] text-emerald-500 font-bold bg-emerald-50 dark:bg-emerald-950/20 px-2 py-0.5 rounded-full">Ready for dispatch</span>
          </div>
          <div className="absolute bottom-0 left-0 h-1 w-full bg-gradient-to-r from-emerald-500 to-teal-500 opacity-80 group-hover:h-1.5 transition-all" />
        </div>

        {/* KPI Card: Active Trips / Pending */}
        <div className="group relative overflow-hidden rounded-3xl border border-white/40 bg-white/70 p-6 shadow-sm transition-all hover:shadow-md dark:border-zinc-800/80 dark:bg-zinc-900/60 backdrop-blur-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase tracking-wider">Trips Dispatched</span>
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-50 text-cyan-600 dark:bg-cyan-950/40 dark:text-cyan-400 shadow-sm">
              <Navigation className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-4 flex items-baseline justify-between">
            <span className="text-3xl font-display font-bold text-gray-900 dark:text-zinc-50">{activeTripsCount}</span>
            <span className="text-[10px] text-cyan-500 font-bold bg-cyan-50 dark:bg-cyan-950/20 px-2 py-0.5 rounded-full">{pendingTripsCount} drafts pending</span>
          </div>
          <div className="absolute bottom-0 left-0 h-1 w-full bg-gradient-to-r from-cyan-500 to-blue-500 opacity-80 group-hover:h-1.5 transition-all" />
        </div>

        {/* KPI Card: Fleet Utilization */}
        <div className="group relative overflow-hidden rounded-3xl border border-white/40 bg-white/70 p-6 shadow-sm transition-all hover:shadow-md dark:border-zinc-800/80 dark:bg-zinc-900/60 backdrop-blur-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase tracking-wider">Fleet Utilization</span>
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-purple-50 text-purple-600 dark:bg-purple-950/40 dark:text-purple-400 shadow-sm">
              <Percent className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-4 flex items-baseline justify-between">
            <span className="text-3xl font-display font-bold text-gray-900 dark:text-zinc-50">{fleetUtilization}%</span>
            <span className="flex items-center text-[10px] text-purple-500 font-bold bg-purple-50 dark:bg-purple-950/20 px-2 py-0.5 rounded-full">
              <TrendingUp className="mr-0.5 h-3 w-3" />
              Optimal
            </span>
          </div>
          <div className="absolute bottom-0 left-0 h-1 w-full bg-gradient-to-r from-purple-500 to-pink-500 opacity-80 group-hover:h-1.5 transition-all" />
        </div>

      </div>

      {/* Safety Compliance & Operation Warnings (Role-Specific Context) */}
      {(currentUser?.role === 'Safety Officer' || currentUser?.role === 'Fleet Manager') && (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          
          {/* License Validity Tracker Card */}
          <div className="overflow-hidden rounded-3xl border border-white/40 bg-white/75 p-6 shadow-md dark:border-zinc-800/80 dark:bg-zinc-900/60 backdrop-blur-md">
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-indigo-700 dark:text-indigo-400">
                <AlertTriangle className="h-5 w-5 shrink-0 text-indigo-500 animate-bounce" />
                <h3 className="font-display font-bold text-sm tracking-tight text-gray-900 dark:text-zinc-50">Critical Driver Compliance Alerts</h3>
              </div>
              
              {expiredLicenses.length === 0 && expiringSoonLicenses.length === 0 ? (
                <p className="text-xs text-gray-500 dark:text-zinc-400 leading-relaxed font-medium">
                  ✓ All driver licenses are currently fully valid and CDL compliant. No immediate renewal operations required.
                </p>
              ) : (
                <ul className="space-y-2 max-h-52 overflow-y-auto pr-1">
                  {expiredLicenses.map((d) => (
                    <li key={d.id} className="flex justify-between items-center bg-white/90 p-2.5 rounded-xl border border-red-100 shadow-sm dark:bg-zinc-950/60 dark:border-red-950/40">
                      <div>
                        <p className="text-xs font-bold text-gray-900 dark:text-zinc-100">{d.name}</p>
                        <p className="text-[10px] text-red-500 font-semibold">LICENSE EXPIRED: {d.licenseExpiryDate}</p>
                      </div>
                      <span className="bg-red-500 text-white text-[9px] font-bold px-2 py-0.5 rounded-full shadow-xs">
                        BLOCKED
                      </span>
                    </li>
                  ))}
                  {expiringSoonLicenses.map((d) => (
                    <li key={d.id} className="flex justify-between items-center bg-white/90 p-2.5 rounded-xl border border-amber-100 shadow-sm dark:bg-zinc-950/60 dark:border-amber-950/40">
                      <div>
                        <p className="text-xs font-bold text-gray-900 dark:text-zinc-100">{d.name}</p>
                        <p className="text-[10px] text-amber-500 font-semibold">EXPIRING SOON: {d.licenseExpiryDate}</p>
                      </div>
                      <span className="bg-amber-100 text-amber-800 text-[9px] font-bold px-2 py-0.5 rounded-full dark:bg-amber-950/40 dark:text-amber-300">
                        WARNING
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>

          {/* Maintenance & Shop Overviews */}
          <div className="overflow-hidden rounded-3xl border border-white/40 bg-white/75 p-6 shadow-md dark:border-zinc-800/80 dark:bg-zinc-900/60 backdrop-blur-md">
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-indigo-700 dark:text-indigo-400">
                <Wrench className="h-5 w-5 shrink-0 text-purple-500 animate-pulse" />
                <h3 className="font-display font-bold text-sm tracking-tight text-gray-900 dark:text-zinc-50">Active Fleet Maintenance Status</h3>
              </div>
              
              {activeMaintenanceCount === 0 ? (
                <p className="text-xs text-gray-500 dark:text-zinc-400 leading-relaxed font-medium">
                  ✓ No vehicles are currently undergoing repairs in the shop. All transport fleets are field ready.
                </p>
              ) : (
                <div className="space-y-2">
                  <p className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold">
                    {activeMaintenanceCount} vehicle(s) flagged <span className="underline decoration-indigo-400">In Shop</span>:
                  </p>
                  <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1">
                    {maintenanceLogs
                      .filter((m) => m.status === 'Active')
                      .map((log) => {
                        const veh = vehicles.find((v) => v.id === log.vehicleId);
                        return (
                          <div key={log.id} className="flex justify-between items-center bg-white/90 p-2 rounded-xl border border-indigo-50 shadow-xs dark:bg-zinc-950/60 dark:border-indigo-950/40">
                            <span className="text-[10px] font-bold text-gray-900 dark:text-zinc-100">{veh?.name}</span>
                            <span className="text-[9px] text-indigo-500 font-medium italic truncate max-w-[120px]">{log.description}</span>
                          </div>
                        );
                      })}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Fleet Operations Registry Card (Visible to Fleet Managers and Safety Officers) */}
          <div className="overflow-hidden rounded-3xl border border-white/40 bg-white/75 p-6 shadow-md dark:border-zinc-800/80 dark:bg-zinc-900/60 backdrop-blur-md flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-indigo-700 dark:text-indigo-400">
                <UserPlus className="h-5 w-5 shrink-0 text-indigo-500" />
                <h3 className="font-display font-bold text-sm tracking-tight text-gray-900 dark:text-zinc-50 font-sans">Fleet Operator Actions</h3>
              </div>
              <p className="text-xs text-gray-500 dark:text-zinc-400 leading-relaxed font-medium">
                Register a newly assigned driver instantly with regulatory CDL credentials, contact details, and default safety metrics.
              </p>
              
              <div className="bg-indigo-50/50 rounded-2xl p-4 border border-indigo-100/50 dark:bg-indigo-950/20 dark:border-indigo-900/40 text-xs text-indigo-700 dark:text-indigo-300">
                <span className="font-bold">Operational Info:</span> Expiry validations and regulatory safety ratings are active during assignment dispatching.
              </div>
            </div>
            
            <button
              onClick={() => setIsDriverModalOpen(true)}
              id="dashboard-quick-register-driver"
              className="mt-5 w-full flex items-center justify-center space-x-2 rounded-2xl bg-indigo-600 px-4 py-3 text-xs font-bold text-white shadow-md transition-all hover:bg-indigo-700 active:scale-[0.98]"
            >
              <Plus className="h-4 w-4" />
              <span>Register New Driver</span>
            </button>
          </div>

        </div>
      )}

      {/* Filter and Master Fleet Status Tracker */}
      <div className="rounded-3xl border border-white/40 bg-white/75 shadow-md dark:border-zinc-800/80 dark:bg-zinc-900/60 backdrop-blur-md overflow-hidden">

        <div className="border-b border-gray-100 p-5 dark:border-zinc-800">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center space-x-2">
              <SlidersHorizontal className="h-4 w-4 text-gray-500 dark:text-zinc-400" />
              <h3 className="font-display font-bold text-gray-900 dark:text-zinc-50">Fleet Asset Monitor</h3>
            </div>
            
            {/* Interactive Filters Panel */}
            <div className="flex flex-wrap items-center gap-2">
              
              {/* Type Filter */}
              <div className="flex flex-col">
                <span className="text-[10px] text-gray-400 font-bold uppercase mb-1">Type</span>
                <select
                  value={selectedType}
                  onChange={(e) => setSelectedType(e.target.value)}
                  className="rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-xs font-semibold text-gray-700 focus:outline-none dark:border-zinc-800 dark:bg-zinc-800 dark:text-zinc-300"
                >
                  {vehicleTypes.map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>

              {/* Status Filter */}
              <div className="flex flex-col">
                <span className="text-[10px] text-gray-400 font-bold uppercase mb-1">Status</span>
                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                  className="rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-xs font-semibold text-gray-700 focus:outline-none dark:border-zinc-800 dark:bg-zinc-800 dark:text-zinc-300"
                >
                  {statusTypes.map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>

              {/* Region Filter */}
              <div className="flex flex-col">
                <span className="text-[10px] text-gray-400 font-bold uppercase mb-1">Region</span>
                <select
                  value={selectedRegion}
                  onChange={(e) => setSelectedRegion(e.target.value)}
                  className="rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-xs font-semibold text-gray-700 focus:outline-none dark:border-zinc-800 dark:bg-zinc-800 dark:text-zinc-300"
                >
                  {regions.map((r) => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
              </div>

            </div>
          </div>
        </div>

        {/* Dynamic Vehicles Table (Responsive on iOS/Android via flex-cards on mobile and table on desktop) */}
        <div className="p-4">
          {filteredVehicles.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Truck className="h-12 w-12 text-gray-300 dark:text-zinc-700" />
              <p className="mt-2 text-sm text-gray-500 dark:text-zinc-400">No vehicles match your active search filters.</p>
            </div>
          ) : (
            <>
              {/* Desktop View Table */}
              <div className="hidden overflow-x-auto rounded-xl border border-gray-100 dark:border-zinc-800 md:block">
                <table className="w-full border-collapse text-left text-sm text-gray-500 dark:text-zinc-400">
                  <thead className="bg-gray-50 text-xs font-bold uppercase text-gray-700 dark:bg-zinc-800/50 dark:text-zinc-300">
                    <tr>
                      <th className="px-6 py-4">Vehicle Model / Name</th>
                      <th className="px-6 py-4">Reg Number</th>
                      <th className="px-6 py-4">Type</th>
                      <th className="px-6 py-4 text-right">Odometer</th>
                      <th className="px-6 py-4">Region</th>
                      <th className="px-6 py-4">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 border-t border-gray-100 dark:divide-zinc-800 dark:border-zinc-800">
                    {filteredVehicles.map((v) => (
                      <tr key={v.id} className="hover:bg-gray-50/50 dark:hover:bg-zinc-800/30">
                        <td className="px-6 py-4 font-semibold text-gray-900 dark:text-zinc-100">{v.name}</td>
                        <td className="px-6 py-4"><span className="font-mono bg-gray-100 dark:bg-zinc-800 px-2 py-0.5 rounded text-xs">{v.registrationNumber}</span></td>
                        <td className="px-6 py-4">{v.type}</td>
                        <td className="px-6 py-4 text-right font-mono">{v.odometer.toLocaleString()} km</td>
                        <td className="px-6 py-4 flex items-center space-x-1.5">
                          <MapPin className="h-3.5 w-3.5 text-gray-400" />
                          <span>{v.region}</span>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                            v.status === 'Available'
                              ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400'
                              : v.status === 'On Trip'
                              ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/30 dark:text-indigo-400'
                              : v.status === 'In Shop'
                              ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400'
                              : 'bg-rose-50 text-rose-700 dark:bg-rose-950/30 dark:text-rose-400'
                          }`}>
                            {v.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile Card Layout for Adaptive iOS/Android UI */}
              <div className="grid gap-4 md:hidden">
                {filteredVehicles.map((v) => (
                  <div key={v.id} className="rounded-xl border border-gray-100 bg-gray-50/30 p-4 dark:border-zinc-800 dark:bg-zinc-800/20">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-bold text-gray-900 dark:text-zinc-50">{v.name}</h4>
                        <p className="mt-1 font-mono text-xs text-gray-400">{v.registrationNumber}</p>
                      </div>
                      <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-bold ${
                        v.status === 'Available'
                          ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400'
                          : v.status === 'On Trip'
                          ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/30 dark:text-indigo-400'
                          : v.status === 'In Shop'
                          ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400'
                          : 'bg-rose-50 text-rose-700 dark:bg-rose-950/30 dark:text-rose-400'
                      }`}>
                        {v.status}
                      </span>
                    </div>
                    <div className="mt-4 grid grid-cols-2 gap-2 text-xs border-t border-gray-100 pt-3 dark:border-zinc-800/80">
                      <div>
                        <p className="text-gray-400">Type</p>
                        <p className="font-semibold text-gray-700 dark:text-zinc-300">{v.type}</p>
                      </div>
                      <div>
                        <p className="text-gray-400">Odometer</p>
                        <p className="font-semibold text-gray-700 dark:text-zinc-300 font-mono">{v.odometer} km</p>
                      </div>
                      <div>
                        <p className="text-gray-400">Region</p>
                        <p className="font-semibold text-gray-700 dark:text-zinc-300 flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {v.region}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Quick Add Driver Dialog Modal */}
      {isDriverModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-lg overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-2xl dark:border-zinc-800 dark:bg-zinc-950">
            <div className="border-b border-gray-100 px-6 py-4 flex items-center justify-between dark:border-zinc-800">
              <div className="flex items-center space-x-2 text-indigo-600 dark:text-indigo-400">
                <UserPlus className="h-5 w-5" />
                <h3 className="font-display font-bold text-gray-900 dark:text-zinc-50">
                  Quick Register Operator
                </h3>
              </div>
              <button
                onClick={() => setIsDriverModalOpen(false)}
                className="p-1 rounded-lg text-gray-400 hover:bg-gray-100 dark:hover:bg-zinc-900"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleQuickAddDriverSubmit} className="p-6 space-y-4">
              
              {driverError && (
                <div className="flex items-center space-x-2 text-rose-600 bg-rose-50/50 p-3 rounded-lg text-xs font-semibold border border-rose-100 dark:bg-rose-950/15 dark:border-rose-900/50">
                  <AlertTriangle className="h-4 w-4 shrink-0" />
                  <span>{driverError}</span>
                </div>
              )}

              {driverSuccess && (
                <div className="flex items-center space-x-2 text-emerald-600 bg-emerald-50/50 p-3 rounded-lg text-xs font-semibold border border-emerald-100 dark:bg-emerald-950/15 dark:border-emerald-900/50">
                  <CheckCircle className="h-4 w-4 shrink-0" />
                  <span>{driverSuccess}</span>
                </div>
              )}

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">
                    Full Name
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Amit Sharma"
                    value={newDriverName}
                    onChange={(e) => setNewDriverName(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">
                    License Number (CDL)
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. DL-CA12345"
                    value={newDriverLicense}
                    onChange={(e) => setNewDriverLicense(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">
                    License Category
                  </label>
                  <select
                    value={newDriverCategory}
                    onChange={(e) => setNewDriverCategory(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                  >
                    <option value="Class A CDL">Class A CDL (Commercial Semi)</option>
                    <option value="Class B CDL">Class B CDL (Commercial Box)</option>
                    <option value="Class C CDL">Class C CDL (Standard Delivery)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">
                    License Expiry Date
                  </label>
                  <input
                    type="date"
                    required
                    value={newDriverExpiry}
                    onChange={(e) => setNewDriverExpiry(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">
                    Contact Number
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. +1 (415) 555-0100"
                    value={newDriverContact}
                    onChange={(e) => setNewDriverContact(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900/50 dark:text-zinc-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">
                    Safety Score (0-100)
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    max="100"
                    value={newDriverSafety}
                    onChange={(e) => setNewDriverSafety(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-gray-700 dark:text-zinc-400 uppercase mb-1">
                    Operator Duty Status
                  </label>
                  <select
                    value={newDriverStatus}
                    onChange={(e) => setNewDriverStatus(e.target.value as any)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
                  >
                    <option value="Available">Available</option>
                    <option value="On Trip">On Trip</option>
                    <option value="Off Duty">Off Duty</option>
                    <option value="Suspended">Suspended</option>
                  </select>
                </div>
              </div>

              <div className="border-t border-gray-100 pt-4 flex justify-end space-x-2 dark:border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsDriverModalOpen(false)}
                  className="rounded-lg border border-gray-200 px-4 py-2 text-xs font-semibold text-gray-500 hover:bg-gray-50 dark:border-zinc-800 dark:text-zinc-400 dark:hover:bg-zinc-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-indigo-600 px-4 py-2 text-xs font-bold text-white shadow-md hover:bg-indigo-700"
                >
                  Register Operator
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};

