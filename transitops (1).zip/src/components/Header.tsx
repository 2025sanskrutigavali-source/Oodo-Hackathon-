/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useTransit } from '../context/TransitContext';
import { Sun, Moon, Wifi, WifiOff, Shield, RefreshCw, User, LogOut } from 'lucide-react';
import { Role } from '../types';

export const Header: React.FC = () => {
  const {
    currentUser,
    switchRole,
    availableRoles,
    darkMode,
    toggleDarkMode,
    isOffline,
    setIsOffline,
    resetToDefault,
    logout
  } = useTransit();

  if (!currentUser) return null;

  return (
    <header className="sticky top-0 z-40 w-full border-b border-gray-200 bg-white/90 backdrop-blur-md transition-colors dark:border-zinc-800 dark:bg-zinc-900/90">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Logo and Brand */}
        <div className="flex items-center space-x-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 shadow-md">
            <span className="font-display text-xl font-bold text-white tracking-wider">T</span>
          </div>
          <div>
            <h1 className="font-display text-lg font-bold tracking-tight text-gray-900 dark:text-zinc-50">
              Transit<span className="text-indigo-500">Ops</span>
            </h1>
            <p className="hidden text-[10px] font-medium text-gray-500 dark:text-zinc-400 sm:block">
              Smart Transport Operations Platform
            </p>
          </div>
        </div>

        {/* Dynamic Navigation & Indicators */}
        <div className="flex items-center space-x-2 sm:space-x-4">
          
          {/* Offline/Online Simulation Toggle */}
          <button
            onClick={() => setIsOffline(!isOffline)}
            id="btn-offline-toggle"
            className={`flex items-center space-x-1.5 rounded-full px-3 py-1 text-xs font-semibold transition-all shadow-sm ${
              isOffline
                ? 'bg-amber-100 text-amber-800 border border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-900/50'
                : 'bg-emerald-50 text-emerald-800 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-900/50'
            }`}
            title="Toggle simulated network status to test offline caching"
          >
            {isOffline ? (
              <>
                <WifiOff className="h-3.5 w-3.5" />
                <span className="hidden xs:inline">Offline Mode</span>
              </>
            ) : (
              <>
                <Wifi className="h-3.5 w-3.5 animate-pulse" />
                <span className="hidden xs:inline">Live Sync</span>
              </>
            )}
          </button>

          {/* Role Quick Switcher (RBAC Tester) */}
          <div className="relative flex items-center space-x-1 bg-gray-100 p-1 rounded-xl dark:bg-zinc-800">
            <Shield className="ml-1.5 h-3.5 w-3.5 text-gray-500 dark:text-zinc-400" />
            <select
              id="select-role-switcher"
              value={currentUser.role}
              onChange={(e) => switchRole(e.target.value as Role)}
              className="bg-transparent text-xs font-semibold text-gray-700 dark:text-zinc-300 focus:outline-none cursor-pointer pr-2 border-none"
              title="Switch role to simulate Role-Based Access Control (RBAC)"
            >
              {availableRoles.map((role) => (
                <option key={role} value={role} className="dark:bg-zinc-900 text-gray-900 dark:text-zinc-100 font-sans">
                  {role}
                </option>
              ))}
            </select>
          </div>

          {/* Reset button to clear custom storage and seed default values */}
          <button
            onClick={() => {
              if (window.confirm('Reset application state to seed values? All custom entries will be restored to demo defaults.')) {
                resetToDefault();
              }
            }}
            id="btn-reset-state"
            className="p-2 text-gray-500 hover:text-gray-900 dark:text-zinc-400 dark:hover:text-zinc-100 rounded-lg transition-colors"
            title="Reset to Demo Seed Data"
          >
            <RefreshCw className="h-4 w-4" />
          </button>

          {/* Theme Toggle Switch */}
          <button
            onClick={toggleDarkMode}
            id="btn-theme-toggle"
            className="group relative inline-flex h-8 w-14 shrink-0 cursor-pointer items-center rounded-full bg-gray-150 p-1 transition-colors duration-300 ease-in-out focus:outline-none dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 shadow-inner"
            title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          >
            <span className="sr-only">Toggle Theme</span>
            {/* Background Icons */}
            <div className="absolute inset-0 flex items-center justify-between px-2 pointer-events-none">
              <Sun className={`h-3.5 w-3.5 transition-opacity duration-300 ${darkMode ? 'opacity-30 text-gray-400' : 'opacity-100 text-amber-500'}`} />
              <Moon className={`h-3.5 w-3.5 transition-opacity duration-300 ${darkMode ? 'opacity-100 text-indigo-400' : 'opacity-30 text-gray-400'}`} />
            </div>
            {/* Sliding Knobs */}
            <span
              className={`pointer-events-none flex h-5.5 w-5.5 items-center justify-center rounded-full bg-white shadow-md ring-0 transition duration-300 ease-in-out dark:bg-zinc-950 ${
                darkMode ? 'translate-x-5.5' : 'translate-x-0'
              }`}
            >
              {darkMode ? (
                <Moon className="h-3 w-3 text-indigo-400" />
              ) : (
                <Sun className="h-3 w-3 text-amber-500" />
              )}
            </span>
          </button>

          {/* Logout / User Account */}
          <div className="flex items-center space-x-2 border-l border-gray-200 pl-2 dark:border-zinc-800 sm:pl-4">
            <div className="hidden text-right md:block">
              <p className="text-xs font-semibold text-gray-900 dark:text-zinc-50">
                {currentUser.name}
              </p>
              <p className="text-[10px] text-gray-400 dark:text-zinc-500">
                {currentUser.email}
              </p>
            </div>
            <button
              onClick={logout}
              id="btn-logout"
              className="p-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-colors"
              title="Sign Out"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
