/**
 * @license
 * SPDX-License-Identifier-2.0
 */

import React, { useState } from 'react';
import { TransitProvider, useTransit } from './context/TransitContext';
import { Header } from './components/Header';
import { Login } from './components/Login';
import { Dashboard } from './components/Dashboard';
import { VehicleRegistry } from './components/VehicleRegistry';
import { DriverManagement } from './components/DriverManagement';
import { TripManagement } from './components/TripManagement';
import { Maintenance } from './components/Maintenance';
import { FuelExpenses } from './components/FuelExpenses';
import { Reports } from './components/Reports';

import {
  LayoutDashboard,
  Truck,
  Users,
  Navigation,
  Wrench,
  DollarSign,
  BarChart3,
  Menu,
  X
} from 'lucide-react';

type Tab = 'dashboard' | 'vehicles' | 'drivers' | 'trips' | 'maintenance' | 'expenses' | 'reports';

const MainLayout.FC = () => {
  const { currentUser } = useTransit();
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  if (!currentUser) {
    return <Login />;
  }

  const tabs = [
    { id'dashboard' as Tab, name'Dashboard', icon},
    { id'vehicles' as Tab, name'Vehicle Registry', icon},
    { id'drivers' as Tab, name'Drivers', icon},
    { id'trips' as Tab, name'Trips & Dispatch', icon},
    { id'maintenance' as Tab, name'Maintenance', icon},
    { id'expenses' as Tab, name'Expenses & Fuel', icon},
    { id'reports' as Tab, name'Reports & ROI', icon}
  ];

  const renderActiveComponent = () => {
    switch (activeTab) {
      case 'dashboard'/>;
      case 'vehicles'/>;
      case 'drivers'/>;
      case 'trips'/>;
      case 'maintenance'/>;
      case 'expenses'/>;
      case 'reports'/>;
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-gradient-to-tr from-slate-50 via-indigo-50/20 to-teal-50/10 text-gray-900 transition-colors dark-zinc-950 dark-zinc-900 dark-zinc-950 dark-zinc-100 flex flex-col">
      {/* Google Flow Ambient Blurred Orbs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute -top-[15%] -left-[10%] w-[45%] h-[45%] rounded-full bg-indigo-300/15 dark-indigo-600/10 blur-[130px]" />
        <div className="absolute top-[30%] -right-[10%] w-[40%] h-[40%] rounded-full bg-purple-300/15 dark-purple-600/10 blur-[130px]" />
        <div className="absolute -bottom-[10%] left-[20%] w-[35%] h-[35%] rounded-full bg-emerald-200/15 dark-emerald-600/5 blur-[100px]" />
      </div>

      {/* Platform Header */}
      <div className="relative z-10">
        <Header />
      </div>

      {/* Main Container - Responsive Layout */}
      <div className="relative z-10 flex-1 flex flex-col md-row max-w-7xl w-full mx-auto px-4 py-6 sm-6 lg-8 gap-6">
        
        {/* Navigation Sidebar (Desktop view) */}
        <aside className="hidden md-64 shrink-0">
          <nav className="space-y-1.5 sticky top-24">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-2xl text-xs font-bold transition-all ${
                    isActive
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10 border-r-4 border-indigo-400'
                      'text-gray-500 hover-gray-950 hover-white/65 dark-zinc-400 dark-zinc-50 dark-zinc-900/60'
                  }`}
                >
                  <Icon className="h-4.5 w-4.5" />
                  <span>{tab.name}</span>
                </button>
              );
            })}
          </nav>
        </aside>


        {/* Bottom Navigation / Menu Bar (Mobile Adaptive Layout for iOS and Android) */}
        <div className="md-center justify-between bg-white dark-zinc-900 border border-gray-150 dark-zinc-800 p-3 rounded-2xl shadow-sm">
          <div className="flex items-center space-x-2">
            {(() => {
              const active = tabs.find((t) => t.id === activeTab);
              const ActiveIcon = active?.icon || LayoutDashboard;
              return (
                <>
                  <ActiveIcon className="h-5 w-5 text-indigo-500" />
                  <span className="text-sm font-bold text-gray-800 dark-zinc-100">{active?.name}</span>
                </>
              );
            })()}
          </div>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            id="btn-mobile-menu"
            className="p-2 text-gray-500 hover-gray-950 dark-zinc-400 dark-zinc-100"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> ="h-5 w-5" />}
          </button>
        </div>

        {/* Mobile dropdown menu */}
        {mobileMenuOpen && (
          <div className="md-cols-2 gap-2 p-4 bg-white dark-zinc-900 border border-gray-150 dark-zinc-800 rounded-2xl shadow-lg">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`flex flex-col items-center justify-center p-3 rounded-xl border transition-all text-center gap-1.5 ${
                    isActive
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                      'border-gray-100 dark-zinc-800 text-gray-500 dark-zinc-400 hover-gray-50 dark-zinc-800/40'
                  }`}
                >
                  <Icon className="h-4.5 w-4.5" />
                  <span className="text-[10px] font-bold">{tab.name}</span>
                </button>
              );
            })}
          </div>
        )}

        {/* Active View Display Container */}
        <main className="flex-1 min-w-0 bg-transparent rounded-2xl">
          {renderActiveComponent()}
        </main>

      </div>

      {/* Footer metadata details */}
      <footer className="relative z-10 mt-auto border-t border-gray-200 py-6 dark-zinc-900 bg-white/50 dark-zinc-950/50">
        <div className="max-w-7xl mx-auto px-4 sm-6 lg-8 flex flex-col sm-row items-center justify-between gap-4 text-[11px] text-gray-400">
          <p>© 2026 TransitOps. Smart Transport Operations Platform. Fully Compliant offline-ready architecture.</p>
          <div className="flex space-x-4">
            <span>Server/span>
            <span>Local Database(Synced)</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <TransitProvider>
      <MainLayout />
    </TransitProvider>
  );
}
