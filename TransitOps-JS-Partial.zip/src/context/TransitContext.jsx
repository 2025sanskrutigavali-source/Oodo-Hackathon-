/**
 * @license
 * SPDX-License-Identifier-2.0
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Vehicle, Driver, Trip, MaintenanceLog, FuelLog, Expense, Role, User } from '../types';
import {
  SEED_VEHICLES,
  SEED_DRIVERS,
  SEED_TRIPS,
  SEED_MAINTENANCE,
  SEED_FUEL_LOGS,
  SEED_EXPENSES
} from '../seedData';

;
  updateVehicle(vehicle) => { success; message};
  deleteVehicle(id) => { success; message};

  addDriver(driver'id'>) => { success; message};
  updateDriver(driver) => { success; message};
  deleteDriver(id) => { success; message};

  addTrip(trip'id' | 'status' | 'createdAt'>) => { success; message};
  dispatchTrip(tripId) => { success; message};
  completeTrip(tripId) => { success; message};
  cancelTrip(tripId) => { success; message};

  addMaintenanceLog(log'id' | 'status'>) => { success; message};
  closeMaintenanceLog(logId) => { success; message};

  addFuelLog(log'id'>) => { success; message};
  addExpense(expense'id'>) => { success; message};

  // Theme & Offline
  darkMode;
  toggleDarkMode() => void;
  isOffline;
  setIsOffline(isOffline) => void;
  resetToDefault() => void;
}

const TransitContext = createContext<TransitContextType | undefined>(undefined);

export const TransitProvider.FC<{ children.ReactNode }> = ({ children }) => {
  // Load initial states from localStorage or use Seeds
  const [currentUser, setCurrentUserState] = useState<User | null>(() => {
    const stored = localStorage.getItem('transit_user');
    if (stored) return JSON.parse(stored);
    // Default logged in as Fleet Manager for ease of evaluation
    return { email'manager@transitops.com', name'Frank Miller', role'Fleet Manager' };
  });

  const [vehicles, setVehicles] = useState<Vehicle[]>(() => {
    const stored = localStorage.getItem('transit_vehicles');
    return stored ? JSON.parse(stored) ;
  });

  const [drivers, setDrivers] = useState<Driver[]>(() => {
    const stored = localStorage.getItem('transit_drivers');
    return stored ? JSON.parse(stored) ;
  });

  const [trips, setTrips] = useState<Trip[]>(() => {
    const stored = localStorage.getItem('transit_trips');
    return stored ? JSON.parse(stored) ;
  });

  const [maintenanceLogs, setMaintenanceLogs] = useState<MaintenanceLog[]>(() => {
    const stored = localStorage.getItem('transit_maintenance');
    return stored ? JSON.parse(stored) ;
  });

  const [fuelLogs, setFuelLogs] = useState<FuelLog[]>(() => {
    const stored = localStorage.getItem('transit_fuel');
    return stored ? JSON.parse(stored) ;
  });

  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const stored = localStorage.getItem('transit_expenses');
    return stored ? JSON.parse(stored) ;
  });

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const stored = localStorage.getItem('transit_dark_mode');
    return stored ? JSON.parse(stored) ; // default to a cool dark mode as requested!
  });

  const [isOffline, setIsOffline] = useState<boolean>(false);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('transit_user', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('transit_vehicles', JSON.stringify(vehicles));
  }, [vehicles]);

  useEffect(() => {
    localStorage.setItem('transit_drivers', JSON.stringify(drivers));
  }, [drivers]);

  useEffect(() => {
    localStorage.setItem('transit_trips', JSON.stringify(trips));
  }, [trips]);

  useEffect(() => {
    localStorage.setItem('transit_maintenance', JSON.stringify(maintenanceLogs));
  }, [maintenanceLogs]);

  useEffect(() => {
    localStorage.setItem('transit_fuel', JSON.stringify(fuelLogs));
  }, [fuelLogs]);

  useEffect(() => {
    localStorage.setItem('transit_expenses', JSON.stringify(expenses));
  }, [expenses]);

  useEffect(() => {
    localStorage.setItem('transit_dark_mode', JSON.stringify(darkMode));
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const availableRoles= [
    'Fleet Manager',
    'Driver',
    'Safety Officer',
    'Financial Analyst'
  ];

  const setCurrentUser = (user) => {
    setCurrentUserState(user);
  };

  const switchRole = (role) => {
    if (currentUser) {
      const emailMap= {
        'Fleet Manager''manager@transitops.com',
        'Driver''driver@transitops.com',
        'Safety Officer''safety@transitops.com',
        'Financial Analyst''analyst@transitops.com'
      };
      const nameMap= {
        'Fleet Manager''Frank Miller',
        'Driver''Alex Rivera',
        'Safety Officer''Sarah Chen',
        'Financial Analyst''Emily Taylor'
      };
      setCurrentUserState({
        email
        name
        role
      });
    }
  };

  const logout = () => {
    setCurrentUserState(null);
  };

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  const resetToDefault = () => {
    setVehicles(SEED_VEHICLES);
    setDrivers(SEED_DRIVERS);
    setTrips(SEED_TRIPS);
    setMaintenanceLogs(SEED_MAINTENANCE);
    setFuelLogs(SEED_FUEL_LOGS);
    setExpenses(SEED_EXPENSES);
  };

  // --- VEHICLE ACTIONS ---
  const addVehicle = (newVeh'id'>) => {
    // Unique registration validation
    const regExists = vehicles.some(
      (v) => v.registrationNumber.trim().toLowerCase() === newVeh.registrationNumber.trim().toLowerCase()
    );
    if (regExists) {
      return { success`Registration number ${newVeh.registrationNumber} already exists!` };
    }

    const vehicle= {
      ...newVeh,
      id'v_' + Date.now(),
      registrationNumber.registrationNumber.trim().toUpperCase()
    };

    setVehicles((prev) => [...prev, vehicle]);
    return { success'Vehicle added successfully' };
  };

  const updateVehicle = (updatedVeh) => {
    // Unique registration validation (excluding self)
    const regExists = vehicles.some(
      (v) =>
        v.id !== updatedVeh.id &&
        v.registrationNumber.trim().toLowerCase() === updatedVeh.registrationNumber.trim().toLowerCase()
    );
    if (regExists) {
      return { success`Registration number ${updatedVeh.registrationNumber} already exists!` };
    }

    setVehicles((prev) => prev.map((v) => (v.id === updatedVeh.id ? updatedVeh )));
    return { success'Vehicle updated successfully' };
  };

  const deleteVehicle = (id) => {
    // Check if vehicle is currently on a trip
    const vehicle = vehicles.find((v) => v.id === id);
    if (vehicle && vehicle.status === 'On Trip') {
      return { success'Cannot delete a vehicle currently on a trip.' };
    }
    setVehicles((prev) => prev.filter((v) => v.id !== id));
    return { success'Vehicle deleted successfully' };
  };

  // --- DRIVER ACTIONS ---
  const addDriver = (newDrv'id'>) => {
    const driver= {
      ...newDrv,
      id'd_' + Date.now()
    };
    setDrivers((prev) => [...prev, driver]);
    return { success'Driver registered successfully' };
  };

  const updateDriver = (updatedDrv) => {
    setDrivers((prev) => prev.map((d) => (d.id === updatedDrv.id ? updatedDrv )));
    return { success'Driver updated successfully' };
  };

  const deleteDriver = (id) => {
    const driver = drivers.find((d) => d.id === id);
    if (driver && driver.status === 'On Trip') {
      return { success'Cannot delete a driver currently on a active trip.' };
    }
    setDrivers((prev) => prev.filter((d) => d.id !== id));
    return { success'Driver profile deleted successfully' };
  };

  // --- TRIP ACTIONS ---
  const addTrip = (newTrip'id' | 'status' | 'createdAt'>) => {
    // Cargo weight validation against vehicle capacity
    const vehicle = vehicles.find((v) => v.id === newTrip.vehicleId);
    if (!vehicle) {
      return { success'Selected vehicle not found.' };
    }
    if (newTrip.cargoWeight > vehicle.maxCapacity) {
      return {
        success
        message`Cargo weight (${newTrip.cargoWeight} kg) exceeds vehicle maximum load capacity (${vehicle.maxCapacity} kg)!`
      };
    }

    // Driver eligibility validation
    const driver = drivers.find((d) => d.id === newTrip.driverId);
    if (!driver) {
      return { success'Selected driver not found.' };
    }

    // Checking safety criteria / expired license
    const today = new Date().toISOString().split('T')[0];
    if (driver.licenseExpiryDate < today) {
      return {
        success
        message`Driver license has expired on ${driver.licenseExpiryDate}! Cannot dispatch.`
      };
    }
    if (driver.status === 'Suspended') {
      return {
        success
        message`Driver is currently Suspended and cannot be assigned to any trip.`
      };
    }

    // Checking availability
    if (vehicle.status !== 'Available') {
      return { success`Vehicle is currently ${vehicle.status} and cannot be assigned.` };
    }
    if (driver.status !== 'Available') {
      return { success`Driver is currently ${driver.status} and cannot be assigned.` };
    }

    const trip= {
      ...newTrip,
      id't_' + Date.now(),
      status'Draft',
      createdAt().toISOString()
    };

    setTrips((prev) => [...prev, trip]);
    return { success'Trip draft created successfully' };
  };

  const dispatchTrip = (tripId) => {
    const trip = trips.find((t) => t.id === tripId);
    if (!trip) return { success'Trip not found.' };

    const vehicle = vehicles.find((v) => v.id === trip.vehicleId);
    const driver = drivers.find((d) => d.id === trip.driverId);

    if (!vehicle || !driver) {
      return { success'Assigned vehicle or driver no longer exists.' };
    }

    // Check availability at dispatch time
    if (vehicle.status !== 'Available' && vehicle.status !== 'On Trip') {
      // (If it was already dispatched, that is fine, but if it is In Shop or Retired, block it)
      return { success`Vehicle status is ${vehicle.status}. Cannot dispatch.` };
    }
    if (driver.status !== 'Available' && driver.status !== 'On Trip') {
      return { success`Driver status is ${driver.status}. Cannot dispatch.` };
    }

    // Enforce expiry dates on dispatch
    const today = new Date().toISOString().split('T')[0];
    if (driver.licenseExpiryDate < today) {
      return { success`Cannot dispatch(${driver.licenseExpiryDate}).` };
    }

    // Update statuses
    setVehicles((prev) =>
      prev.map((v) => (v.id === vehicle.id ? { ...v, status'On Trip' as const } ))
    );
    setDrivers((prev) =>
      prev.map((d) => (d.id === driver.id ? { ...d, status'On Trip' as const } ))
    );
    setTrips((prev) =>
      prev.map((t) =>
        t.id === tripId ? { ...t, status'Dispatched' as const, dispatchedAt().toISOString() } 
      )
    );

    return { success'Trip dispatched successfully!' };
  };

  const completeTrip = (tripId) => {
    const trip = trips.find((t) => t.id === tripId);
    if (!trip) return { success'Trip not found.' };

    const vehicle = vehicles.find((v) => v.id === trip.vehicleId);
    if (!vehicle) return { success'Vehicle not found.' };

    if (finalOdometer < vehicle.odometer) {
      return {
        success
        message`Final odometer (${finalOdometer} km) cannot be less than vehicle starting odometer (${vehicle.odometer} km).`
      };
    }

    // Update vehicle odometer and return both vehicle and driver to Available
    setVehicles((prev) =>
      prev.map((v) =>
        v.id === trip.vehicleId
          ? { ...v, odometer'Available' as const }
          
      )
    );

    setDrivers((prev) =>
      prev.map((d) =>
        d.id === trip.driverId ? { ...d, status'Available' as const } 
      )
    );

    setTrips((prev) =>
      prev.map((t) =>
        t.id === tripId
          ? {
              ...t,
              status'Completed' as const,
              completedAt().toISOString(),
              finalOdometer,
              fuelConsumed,
              revenue
            }
          
      )
    );

    // Auto-record a fuel log for analytics tracking if fuel was consumed
    if (fuelConsumed > 0) {
      const fuelCost = fuelConsumed * 1.6; // estimate average price per liter
      addFuelLog({
        vehicleId.vehicleId,
        liters
        cost(fuelCost.toFixed(2)),
        date().toISOString().split('T')[0]
      });
    }

    return { success'Trip completed successfully! Vehicle and driver are now Available.' };
  };

  const cancelTrip = (tripId) => {
    const trip = trips.find((t) => t.id === tripId);
    if (!trip) return { success'Trip not found.' };

    // Restore vehicle and driver to Available if canceled from Dispatched state
    if (trip.status === 'Dispatched') {
      setVehicles((prev) =>
        prev.map((v) => (v.id === trip.vehicleId ? { ...v, status'Available' as const } ))
      );
      setDrivers((prev) =>
        prev.map((d) => (d.id === trip.driverId ? { ...d, status'Available' as const } ))
      );
    }

    setTrips((prev) =>
      prev.map((t) => (t.id === tripId ? { ...t, status'Cancelled' as const } ))
    );

    return { success'Trip cancelled successfully.' };
  };

  // --- MAINTENANCE ACTIONS ---
  const addMaintenanceLog = (newLog'id' | 'status'>) => {
    const log= {
      ...newLog,
      id'm_' + Date.now(),
      status'Active'
    };

    // Auto switch vehicle to "In Shop"
    setVehicles((prev) =>
      prev.map((v) => (v.id === newLog.vehicleId ? { ...v, status'In Shop' as const } ))
    );

    // If driver was assigning to this vehicle on active trips, or other states, handled.
    setMaintenanceLogs((prev) => [...prev, log]);

    // Also auto-add to operational expenses as a Maintenance expense
    addExpense({
      vehicleId.vehicleId,
      category'Other',
      cost.cost,
      date.startDate,
      description`Maintenance${newLog.description}`
    });

    return { success'Vehicle sent to shop and maintenance log opened.' };
  };

  const closeMaintenanceLog = (logId) => {
    const log = maintenanceLogs.find((l) => l.id === logId);
    if (!log) return { success'Log not found.' };

    const updatedCost = closingCost !== undefined ? closingCost .cost;

    setMaintenanceLogs((prev) =>
      prev.map((l) =>
        l.id === logId
          ? {
              ...l,
              status'Closed' as const,
              endDate().toISOString().split('T')[0],
              cost
            }
          
      )
    );

    // Restore vehicle to Available (unless retired)
    setVehicles((prev) =>
      prev.map((v) => {
        if (v.id === log.vehicleId) {
          return {
            ...v,
            status.status === 'Retired' ? ('Retired' as const) ('Available' as const)
          };
        }
        return v;
      })
    );

    return { success'Maintenance record completed. Vehicle is now Available.' };
  };

  // --- FUEL & EXPENSE ACTIONS ---
  const addFuelLog = (newFuel'id'>) => {
    const log= {
      ...newFuel,
      id'f_' + Date.now()
    };
    setFuelLogs((prev) => [...prev, log]);
    return { success'Fuel refuel logged successfully.' };
  };

  const addExpense = (newExp'id'>) => {
    const exp= {
      ...newExp,
      id'e_' + Date.now()
    };
    setExpenses((prev) => [...prev, exp]);
    return { success'Expense recorded successfully.' };
  };

  return (
    <TransitContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        availableRoles,
        switchRole,
        logout,
        vehicles,
        drivers,
        trips,
        maintenanceLogs,
        fuelLogs,
        expenses,
        addVehicle,
        updateVehicle,
        deleteVehicle,
        addDriver,
        updateDriver,
        deleteDriver,
        addTrip,
        dispatchTrip,
        completeTrip,
        cancelTrip,
        addMaintenanceLog,
        closeMaintenanceLog,
        addFuelLog,
        addExpense,
        darkMode,
        toggleDarkMode,
        isOffline,
        setIsOffline,
        resetToDefault
      }}
    >
      {children}
    </TransitContext.Provider>
  );
};

export const useTransit = () => {
  const context = useContext(TransitContext);
  if (context === undefined) {
    throw new Error('useTransit must be used within a TransitProvider');
  }
  return context;
};
