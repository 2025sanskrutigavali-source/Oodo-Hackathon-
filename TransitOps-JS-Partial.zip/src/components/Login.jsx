/**
 * @license
 * SPDX-License-Identifier-2.0
 */

import React, { useState } from 'react';
import { useTransit } from '../context/TransitContext';
import { Shield, Key, Mail, CheckCircle, ArrowRight, Sun, Moon } from 'lucide-react';
import { Role } from '../types';

export const Login.FC = () => {
  const { setCurrentUser, darkMode, toggleDarkMode } = useTransit();
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [selectedRole, setSelectedRole] = useState<Role>('Fleet Manager');
  const [isDemo, setIsDemo] = useState(true);

  const demoAccounts = [
    {
      role'Fleet Manager' as Role,
      email'manager@transitops.com',
      name'Frank Miller',
      desc'Asset control, shop dispatch, and operational reviews.'
    },
    {
      role'Driver' as Role,
      email'driver@transitops.com',
      name'Alex Rivera',
      desc'Create trips, complete deliveries, and log telemetry.'
    },
    {
      role'Safety Officer' as Role,
      email'safety@transitops.com',
      name'Sarah Chen',
      desc'Audit driver compliance, tracking CDL expiry & scores.'
    },
    {
      role'Financial Analyst' as Role,
      email'analyst@transitops.com',
      name'Emily Taylor',
      desc'Log fuel refills, track toll expenses, and analyze ROI.'
    }
  ];

  const handleDemoSelect = (demo) => {
    setEmail(demo.email);
    setName(demo.name);
    setSelectedRole(demo.role);
    setPassword('demopass123');
  };

  const handleSubmit = (e.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;

    // Enforce credentials name default if not specified
    const finalName = name || (email.includes('manager') ? 'Frank Miller' .includes('driver') ? 'Alex Rivera' .includes('safety') ? 'Sarah Chen' 'Emily Taylor');
    
    setCurrentUser({
      email,
      name
      role
    });
  };

  return (
    <div className="min-h-screen flex flex-col justify-center py-12 sm-6 lg-8 bg-gray-50 text-gray-900 transition-colors dark-zinc-950 dark-zinc-100">
      
      {/* Theme Switcher in Corner */}
      <div className="absolute top-4 right-4">
        <button
          onClick={toggleDarkMode}
          className="p-2.5 rounded-xl bg-gray-100 hover-gray-200 dark-zinc-900 dark-zinc-800 transition-colors text-gray-600 dark-zinc-400"
          title={darkMode ? 'Switch to Light Mode' 'Switch to Dark Mode'}
        >
          {darkMode ? <Sun className="h-5 w-5 text-amber-400" /> ="h-5 w-5" />}
        </button>
      </div>

      <div className="sm-auto sm-full sm-w-md text-center">
        {/* Logo and title */}
        <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 shadow-lg text-white font-display text-2xl font-bold tracking-wider mb-4">
          T
        </div>
        <h2 className="text-3xl font-display font-bold tracking-tight text-gray-900 dark-zinc-50">
          Transit<span className="text-indigo-500">Ops</span> Login
        </h2>
        <p className="mt-1.5 text-xs text-gray-500 dark-zinc-400 max-w-sm mx-auto">
          Securely log in to administer fleet vehicle databases, trip dispatches, safety CDL records, and expense analytics.
        </p>
      </div>

      <div className="mt-8 sm-auto sm-full sm-w-xl">
        <div className="bg-white py-8 px-4 border border-gray-200 shadow-xl rounded-3xl dark-zinc-900 dark-zinc-900 sm-10">
          
          <div className="grid gap-6 md-cols-5">
            
            {/* Quick Demo Selector for fast evaluation */}
            <div className="md-span-2 space-y-3.5 border-b border-gray-100 pb-5 md-b-0 md-0 md-r md-5 dark-zinc-800">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">
                Evaluate Role (RBAC)
              </p>
              {demoAccounts.map((demo) => {
                const isActive = email === demo.email;
                return (
                  <button
                    key={demo.role}
                    type="button"
                    onClick={() => handleDemoSelect(demo)}
                    className={`w-full text-left p-3 rounded-2xl border text-xs transition-all shadow-2xs ${
                      isActive
                        ? 'border-indigo-500 bg-indigo-500/5 dark-indigo-500/10'
                        'border-gray-100 bg-gray-50/50 dark-zinc-850 dark-zinc-850/50 hover-gray-100/50'
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-gray-900 dark-zinc-100">{demo.role}</span>
                      {isActive && <CheckCircle className="h-3.5 w-3.5 text-indigo-500 shrink-0" />}
                    </div>
                    <p className="text-[10px] text-gray-400 mt-1 italic">{demo.name}</p>
                  </button>
                );
              })}
            </div>

            {/* Standard Login Form */}
            <form onSubmit={handleSubmit} className="md-span-3 space-y-4">
              <div>
                <label htmlFor="email" className="block text-xs font-bold text-gray-400 uppercase mb-1">
                  Email address
                </label>
                <div className="relative flex items-center">
                  <Mail className="absolute left-3 h-4 w-4 text-gray-400" />
                  <input
                    id="email"
                    name="email"
                    type="email"
                    required
                    placeholder="e.g. manager@transitops.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full rounded-xl border border-gray-250 pl-10 pr-3 py-2.5 text-xs text-gray-950 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-950 dark-zinc-100"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="name-input" className="block text-xs font-bold text-gray-400 uppercase mb-1">
                  Full Name (Optional)
                </label>
                <input
                  id="name-input"
                  name="name"
                  type="text"
                  placeholder="e.g. Frank Miller"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full rounded-xl border border-gray-250 px-3 py-2.5 text-xs text-gray-950 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-950 dark-zinc-100"
                />
              </div>

              <div>
                <label htmlFor="role-select" className="block text-xs font-bold text-gray-400 uppercase mb-1">
                  Assigned RBAC Role
                </label>
                <select
                  id="role-select"
                  value={selectedRole}
                  onChange={(e) => setSelectedRole(e.target.value as Role)}
                  className="w-full rounded-xl border border-gray-250 px-3 py-2.5 text-xs text-gray-950 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-950 dark-zinc-100"
                >
                  <option value="Fleet Manager">Fleet Manager</option>
                  <option value="Driver">Driver</option>
                  <option value="Safety Officer">Safety Officer</option>
                  <option value="Financial Analyst">Financial Analyst</option>
                </select>
              </div>

              <div>
                <label htmlFor="password" className="block text-xs font-bold text-gray-400 uppercase mb-1">
                  Password
                </label>
                <div className="relative flex items-center">
                  <Key className="absolute left-3 h-4 w-4 text-gray-400" />
                  <input
                    id="password"
                    name="password"
                    type="password"
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full rounded-xl border border-gray-250 pl-10 pr-3 py-2.5 text-xs text-gray-950 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-950 dark-zinc-100"
                  />
                </div>
              </div>

              <button
                type="submit"
                id="btn-login-submit"
                className="w-full flex items-center justify-center space-x-1.5 rounded-xl bg-indigo-600 px-4 py-3 text-xs font-bold text-white shadow-md hover-indigo-750 active-98 transition-all"
              >
                <span>Authorize & Connect</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </form>

          </div>

        </div>
      </div>
    </div>
  );
};
