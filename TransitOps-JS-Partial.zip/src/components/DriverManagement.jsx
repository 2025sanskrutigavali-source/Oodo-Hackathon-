/**
 * @license
 * SPDX-License-Identifier-2.0
 */

import React, { useState } from 'react';
import { useTransit } from '../context/TransitContext';
import { Users, Plus, Edit2, Trash2, ShieldAlert, X, Heart, Calendar, Phone, Award, AlertTriangle, CheckCircle, AlertCircle } from 'lucide-react';
import { Driver, DriverStatus } from '../types';

export const DriverManagement.FC = () => {
  const { drivers, addDriver, updateDriver, deleteDriver, currentUser } = useTransit();

  // Dialog State
  const [isOpen, setIsOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [licenseNumber, setLicenseNumber] = useState('');
  const [licenseCategory, setLicenseCategory] = useState('Class A CDL');
  const [licenseExpiryDate, setLicenseExpiryDate] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [safetyScore, setSafetyScore] = useState<number>(100);
  const [status, setStatus] = useState<DriverStatus>('Available');

  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const canManage = currentUser?.role === 'Safety Officer' || currentUser?.role === 'Fleet Manager';

  const resetForm = () => {
    setName('');
    setLicenseNumber('');
    setLicenseCategory('Class A CDL');
    setLicenseExpiryDate('');
    setContactNumber('');
    setSafetyScore(100);
    setStatus('Available');
    setErrorMessage(null);
    setSuccessMessage(null);
    setEditId(null);
    setIsEditing(false);
  };

  const handleOpenCreate = () => {
    resetForm();
    setIsOpen(true);
  };

  const handleOpenEdit = (d) => {
    setName(d.name);
    setLicenseNumber(d.licenseNumber);
    setLicenseCategory(d.licenseCategory);
    setLicenseExpiryDate(d.licenseExpiryDate);
    setContactNumber(d.contactNumber);
    setSafetyScore(d.safetyScore);
    setStatus(d.status);
    setEditId(d.id);
    setIsEditing(true);
    setIsOpen(true);
    setErrorMessage(null);
    setSuccessMessage(null);
  };

  const handleSubmit = (e.FormEvent) => {
    e.preventDefault();
    if (!canManage) {
      setErrorMessage('Access Denied.');
      return;
    }

    if (!name || !licenseNumber || !licenseExpiryDate || !contactNumber || safetyScore < 0 || safetyScore > 100) {
      setErrorMessage('Please fill in all details with a valid safety score (0-100).');
      return;
    }

    const driverData = {
      name,
      licenseNumber,
      licenseCategory,
      licenseExpiryDate,
      contactNumber,
      safetyScore,
      status
    };

    let result;
    if (isEditing && editId) {
      result = updateDriver({ ...driverData, id});
    } else {
      result = addDriver(driverData);
    }

    if (result.success) {
      setSuccessMessage(result.message);
      setTimeout(() => {
        setIsOpen(false);
        resetForm();
      }, 1000);
    } else {
      setErrorMessage(result.message);
    }
  };

  const handleDelete = (id) => {
    if (!canManage) {
      alert('Access Denied.');
      return;
    }
    if (window.confirm('Are you sure you want to remove this driver profile?')) {
      const res = deleteDriver(id);
      if (!res.success) {
        alert(res.message);
      }
    }
  };

  // Helper to determine safety score style
  const getSafetyScoreBadgeColor = (score) => {
    if (score >= 90) return 'text-emerald-500 bg-emerald-50 dark-emerald-950/20';
    if (score >= 80) return 'text-amber-500 bg-amber-50 dark-amber-950/20';
    return 'text-rose-500 bg-rose-50 dark-rose-950/20';
  };

  // Check if a date is expired
  const todayStr = new Date().toISOString().split('T')[0];
  const isLicenseExpired = (expiryDate) => expiryDate < todayStr;

  return (
    <div className="space-y-6">
      
      {/* RBAC Warning Banner */}
      {!canManage && (
        <div id="rbac-warning-driver" className="flex items-center space-x-3 rounded-xl bg-purple-500/10 p-4 border border-purple-500/30 text-purple-700 dark-purple-400">
          <ShieldAlert className="h-5 w-5 shrink-0 text-purple-500" />
          <div className="text-xs font-semibold">
            <span className="font-bold">Role Restriction/span> Only users with the <span className="font-bold underline text-purple-600 dark-purple-400">Safety Officer</span> or <span className="font-bold underline text-purple-600 dark-purple-400">Fleet Manager</span> role can manage driver profiles and safety ratings. You are currently viewing as <span className="italic">{currentUser?.role}</span>.
          </div>
        </div>
      )}

      {/* Header section */}
      <div className="flex flex-col gap-4 sm-row sm-center sm-between">
        <div>
          <h2 className="font-display text-xl font-bold tracking-tight text-gray-900 dark-zinc-50">
            Driver Management
          </h2>
          <p className="text-xs text-gray-500 dark-zinc-400">
            Register operator profiles, monitor active CDL validity, and analyze safety indicators.
          </p>
        </div>
        
        {canManage && (
          <button
            onClick={handleOpenCreate}
            id="btn-register-driver"
            className="flex items-center justify-center space-x-2 rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-bold text-white shadow-md transition-all hover-indigo-700 active-95"
          >
            <Plus className="h-4 w-4" />
            <span>Register Driver</span>
          </button>
        )}
      </div>

      {/* Driver Profiles Table/List */}
      <div className="rounded-2xl border border-gray-200 bg-white shadow-sm dark-zinc-800 dark-zinc-900 overflow-hidden">
        
        {/* Desktop Table View */}
        <div className="hidden overflow-x-auto md">
          <table className="w-full border-collapse text-left text-sm text-gray-500 dark-zinc-400">
            <thead className="bg-gray-50 text-xs font-bold uppercase text-gray-700 dark-zinc-800/50 dark-zinc-300">
              <tr>
                <th className="px-6 py-4">Driver Name</th>
                <th className="px-6 py-4">License Category</th>
                <th className="px-6 py-4">License Details</th>
                <th className="px-6 py-4">Contact Info</th>
                <th className="px-6 py-4 text-center">Safety Score</th>
                <th className="px-6 py-4">Status</th>
                {canManage && <th className="px-6 py-4 text-right">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 border-t border-gray-100 dark-zinc-800 dark-zinc-800">
              {drivers.map((d) => {
                const expired = isLicenseExpired(d.licenseExpiryDate);
                return (
                  <tr key={d.id} className="hover-gray-50/50 dark-zinc-800/30">
                    <td className="px-6 py-4 font-bold text-gray-900 dark-zinc-100">{d.name}</td>
                    <td className="px-6 py-4">
                      <span className="font-semibold bg-gray-50 dark-zinc-800 text-gray-600 dark-zinc-400 px-2 py-1 rounded text-xs">
                        {d.licenseCategory}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-col">
                        <span className="font-mono text-xs font-semibold">{d.licenseNumber}</span>
                        <span className={`text-[10px] font-bold mt-0.5 flex items-center ${expired ? 'text-rose-500' 'text-gray-400 dark-zinc-500'}`}>
                          <Calendar className="mr-1 h-3 w-3" />
                          Expiry{d.licenseExpiryDate} {expired && '(EXPIRED)'}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-1 font-mono text-xs text-gray-600 dark-zinc-400">
                        <Phone className="h-3.5 w-3.5 text-gray-400" />
                        <span>{d.contactNumber}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <div className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full font-bold text-xs font-mono border border-gray-100 dark-zinc-800 shadow-2xs">
                        <Award className="h-3.5 w-3.5 text-amber-500" />
                        <span className={getSafetyScoreBadgeColor(d.safetyScore)}>{d.safetyScore} / 100</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                        d.status === 'Available'
                          ? 'bg-emerald-50 text-emerald-700 dark-emerald-950/30 dark-emerald-400'
                          .status === 'On Trip'
                          ? 'bg-indigo-50 text-indigo-700 dark-indigo-950/30 dark-indigo-400'
                          .status === 'Off Duty'
                          ? 'bg-gray-100 text-gray-600 dark-zinc-800 dark-zinc-400'
                          'bg-rose-50 text-rose-700 dark-rose-950/30 dark-rose-400'
                      }`}>
                        {d.status}
                      </span>
                    </td>
                    {canManage && (
                      <td className="px-6 py-4 text-right">
                        <div className="flex justify-end space-x-2">
                          <button
                            onClick={() => handleOpenEdit(d)}
                            className="p-1.5 text-indigo-500 hover-indigo-50 dark-indigo-950/40 rounded-lg transition-colors"
                            title="Edit Driver"
                          >
                            <Edit2 className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(d.id)}
                            className="p-1.5 text-rose-500 hover-rose-50 dark-rose-950/40 rounded-lg transition-colors"
                            title="Remove Driver"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Mobile View Adaptive Layout */}
        <div className="grid gap-4 p-4 md">
          {drivers.map((d) => {
            const expired = isLicenseExpired(d.licenseExpiryDate);
            return (
              <div key={d.id} className="rounded-xl border border-gray-100 bg-gray-50/20 p-4 dark-zinc-800 dark-zinc-800/20">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-gray-900 dark-zinc-50">{d.name}</h4>
                    <span className="inline-block mt-1 bg-gray-100 dark-zinc-800 text-gray-600 dark-zinc-400 text-[10px] font-bold px-1.5 py-0.5 rounded">
                      {d.licenseCategory}
                    </span>
                  </div>
                  <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-bold ${
                    d.status === 'Available'
                      ? 'bg-emerald-50 text-emerald-700 dark-emerald-950/30 dark-emerald-400'
                      .status === 'On Trip'
                      ? 'bg-indigo-50 text-indigo-700 dark-indigo-950/30 dark-indigo-400'
                      .status === 'Off Duty'
                      ? 'bg-gray-100 text-gray-600 dark-zinc-800 dark-zinc-400'
                      'bg-rose-50 text-rose-700 dark-rose-950/30 dark-rose-400'
                  }`}>
                    {d.status}
                  </span>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-2 text-xs border-t border-gray-100 pt-3 dark-zinc-800/60">
                  <div>
                    <p className="text-gray-400">License Num</p>
                    <p className="font-mono font-semibold text-gray-700 dark-zinc-300">{d.licenseNumber}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Contact</p>
                    <p className="font-semibold text-gray-700 dark-zinc-300">{d.contactNumber}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Safety Score</p>
                    <p className="font-semibold text-gray-700 dark-zinc-300 font-mono">{d.safetyScore}/100</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Expiry</p>
                    <p className={`font-semibold font-mono ${expired ? 'text-rose-500 font-bold' 'text-gray-700 dark-zinc-300'}`}>
                      {d.licenseExpiryDate}
                    </p>
                  </div>
                </div>

                {canManage && (
                  <div className="mt-4 flex justify-end space-x-2 border-t border-gray-100 pt-3 dark-zinc-800/60">
                    <button
                      onClick={() => handleOpenEdit(d)}
                      className="flex items-center space-x-1.5 px-3 py-1.5 text-xs text-indigo-600 bg-indigo-50 rounded-lg font-bold dark-indigo-950/30 dark-indigo-400"
                    >
                      <Edit2 className="h-3 w-3" />
                      <span>Edit</span>
                    </button>
                    <button
                      onClick={() => handleDelete(d.id)}
                      className="flex items-center space-x-1.5 px-3 py-1.5 text-xs text-rose-600 bg-rose-50 rounded-lg font-bold dark-rose-950/30 dark-rose-400"
                    >
                      <Trash2 className="h-3 w-3" />
                      <span>Delete</span>
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>

      {/* Register/Edit Driver Dialog Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-lg overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-2xl dark-zinc-800 dark-zinc-950">
            <div className="border-b border-gray-100 px-6 py-4 flex items-center justify-between dark-zinc-800">
              <div className="flex items-center space-x-2 text-indigo-600 dark-indigo-400">
                <Users className="h-5 w-5" />
                <h3 className="font-display font-bold text-gray-900 dark-zinc-50">
                  {isEditing ? 'Modify Driver Profile' 'Register Operator'}
                </h3>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1 rounded-lg text-gray-400 hover-gray-100 dark-zinc-900"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              
              {errorMessage && (
                <div className="flex items-center space-x-2 text-rose-600 bg-rose-50/50 p-3 rounded-lg text-xs font-semibold border border-rose-100 dark-rose-950/15 dark-rose-900/50">
                  <AlertCircle className="h-4 w-4 shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {successMessage && (
                <div className="flex items-center space-x-2 text-emerald-600 bg-emerald-50/50 p-3 rounded-lg text-xs font-semibold border border-emerald-100 dark-emerald-950/15 dark-emerald-900/50">
                  <CheckCircle className="h-4 w-4 shrink-0" />
                  <span>{successMessage}</span>
                </div>
              )}

              <div className="grid gap-4 sm-cols-2">
                <div>
                  <label className="block text-xs font-bold text-gray-700 dark-zinc-400 uppercase mb-1">
                    Full Name
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Marcus Aurelius"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-900 dark-zinc-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark-zinc-400 uppercase mb-1">
                    License Number (CDL)
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. DL-CA12345"
                    value={licenseNumber}
                    onChange={(e) => setLicenseNumber(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-900 dark-zinc-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark-zinc-400 uppercase mb-1">
                    License Category
                  </label>
                  <select
                    value={licenseCategory}
                    onChange={(e) => setLicenseCategory(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-900 dark-zinc-100"
                  >
                    <option value="Class A CDL">Class A CDL (Commercial Semi)</option>
                    <option value="Class B CDL">Class B CDL (Commercial Box)</option>
                    <option value="Class C CDL">Class C CDL (Standard Delivery)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark-zinc-400 uppercase mb-1">
                    License Expiry Date
                  </label>
                  <input
                    type="date"
                    required
                    value={licenseExpiryDate}
                    onChange={(e) => setLicenseExpiryDate(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-900 dark-zinc-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark-zinc-400 uppercase mb-1">
                    Contact Number
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. +1 (415) 555-0100"
                    value={contactNumber}
                    onChange={(e) => setContactNumber(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-900 dark-zinc-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark-zinc-400 uppercase mb-1">
                    Safety Score (0-100)
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    max="100"
                    value={safetyScore}
                    onChange={(e) => setSafetyScore(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-900 dark-zinc-100"
                  />
                </div>

                <div className="sm-span-2">
                  <label className="block text-xs font-bold text-gray-700 dark-zinc-400 uppercase mb-1">
                    Operator Duty Status
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as DriverStatus)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-900 dark-zinc-100"
                  >
                    <option value="Available">Available</option>
                    <option value="On Trip">On Trip</option>
                    <option value="Off Duty">Off Duty</option>
                    <option value="Suspended">Suspended</option>
                  </select>
                </div>
              </div>

              <div className="border-t border-gray-100 pt-4 flex justify-end space-x-2 dark-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="rounded-lg border border-gray-200 px-4 py-2 text-xs font-semibold text-gray-500 hover-gray-50 dark-zinc-800 dark-zinc-400 dark-zinc-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-indigo-600 px-4 py-2 text-xs font-bold text-white shadow-md hover-indigo-700"
                >
                  {isEditing ? 'Save operator' 'Register Operator'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
