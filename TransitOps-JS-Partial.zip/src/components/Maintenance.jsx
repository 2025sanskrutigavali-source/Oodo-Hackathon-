/**
 * @license
 * SPDX-License-Identifier-2.0
 */

import React, { useState } from 'react';
import { useTransit } from '../context/TransitContext';
import {
  Wrench,
  Plus,
  X,
  CheckCircle,
  AlertCircle,
  ShieldAlert,
  Archive,
  Calendar,
  DollarSign
} from 'lucide-react';
import { MaintenanceLog } from '../types';

export const Maintenance.FC = () => {
  const {
    maintenanceLogs,
    vehicles,
    addMaintenanceLog,
    closeMaintenanceLog,
    currentUser
  } = useTransit();

  const [isOpen, setIsOpen] = useState(false);
  const [selectedVehicleId, setSelectedVehicleId] = useState('');
  const [description, setDescription] = useState('');
  const [cost, setCost] = useState<number>(0);
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);

  const [formError, setFormError] = useState<string | null>(null);
  const [formSuccess, setFormSuccess] = useState<string | null>(null);

  // Closing logs modal/form state
  const [closingLogId, setClosingLogId] = useState<string | null>(null);
  const [finalCost, setFinalCost] = useState<number>(0);

  const isManager = currentUser?.role === 'Fleet Manager';

  // Vehicles eligible for shop booking (exclude retired/already in shop)
  const availableVehicles = vehicles.filter((v) => v.status !== 'Retired' && v.status !== 'In Shop');

  const handleOpenCreate = () => {
    setSelectedVehicleId(availableVehicles[0]?.id || '');
    setDescription('');
    setCost(150);
    setStartDate(new Date().toISOString().split('T')[0]);
    setFormError(null);
    setFormSuccess(null);
    setIsOpen(true);
  };

  const handleSubmitLog = (e.FormEvent) => {
    e.preventDefault();
    if (!isManager) {
      setFormError('Access Denied.');
      return;
    }

    if (!selectedVehicleId || !description || cost < 0 || !startDate) {
      setFormError('Please fill in valid maintenance parameters.');
      return;
    }

    const res = addMaintenanceLog({
      vehicleId
      description,
      cost,
      startDate
    });

    if (res.success) {
      setFormSuccess('Maintenance request successfully opened and vehicle sent to shop!');
      setTimeout(() => {
        setIsOpen(false);
      }, 1000);
    } else {
      setFormError(res.message);
    }
  };

  const handleOpenCloseLog = (log) => {
    setClosingLogId(log.id);
    setFinalCost(log.cost);
  };

  const handleCloseLog = (e.FormEvent) => {
    e.preventDefault();
    if (!closingLogId) return;

    const res = closeMaintenanceLog(closingLogId, finalCost);
    if (res.success) {
      setClosingLogId(null);
    } else {
      alert(res.message);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* RBAC Warning */}
      {!isManager && (
        <div id="rbac-warning-maintenance" className="flex items-center space-x-3 rounded-xl bg-indigo-500/10 p-4 border border-indigo-500/30 text-indigo-700 dark-indigo-400">
          <ShieldAlert className="h-5 w-5 shrink-0 text-indigo-500" />
          <div className="text-xs font-semibold">
            <span className="font-bold">Role Restriction/span> Only users with the <span className="font-bold underline text-indigo-600 dark-indigo-400">Fleet Manager</span> role can dispatch vehicles to the maintenance shop or close open repair files. Current role="italic">{currentUser?.role}</span>.
          </div>
        </div>
      )}

      {/* Title */}
      <div className="flex flex-col gap-4 sm-row sm-center sm-between">
        <div>
          <h2 className="font-display text-xl font-bold tracking-tight text-gray-900 dark-zinc-50">
            Maintenance & Shop Management
          </h2>
          <p className="text-xs text-gray-500 dark-zinc-400">
            Book assets for maintenance, track repair diagnostics, and restore vehicles to Available pool.
          </p>
        </div>

        {isManager && (
          <button
            onClick={handleOpenCreate}
            id="btn-schedule-maintenance"
            className="flex items-center justify-center space-x-2 rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-bold text-white shadow-md transition-all hover-indigo-700 active-95"
          >
            <Plus className="h-4 w-4" />
            <span>Send Vehicle to Shop</span>
          </button>
        )}
      </div>

      {/* Grid containing logs list */}
      <div className="rounded-2xl border border-gray-200 bg-white shadow-sm dark-zinc-800 dark-zinc-900 overflow-hidden">
        <div className="border-b border-gray-100 p-5 dark-zinc-800">
          <div className="flex items-center space-x-2">
            <Archive className="h-4 w-4 text-gray-500 dark-zinc-400" />
            <h3 className="font-display font-bold text-gray-900 dark-zinc-50">Maintenance Work Orders</h3>
          </div>
        </div>

        {/* Desktop View Table */}
        <div className="hidden overflow-x-auto md">
          <table className="w-full border-collapse text-left text-sm text-gray-500 dark-zinc-400">
            <thead className="bg-gray-50 text-xs font-bold uppercase text-gray-700 dark-zinc-800/50 dark-zinc-300">
              <tr>
                <th className="px-6 py-4">Vehicle Identity</th>
                <th className="px-6 py-4">Work Order Details</th>
                <th className="px-6 py-4">Repair Date Range</th>
                <th className="px-6 py-4 text-right">Estimated Cost</th>
                <th className="px-6 py-4">Work Order Status</th>
                {isManager && <th className="px-6 py-4 text-right">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 border-t border-gray-100 dark-zinc-800 dark-zinc-800">
              {maintenanceLogs.map((log) => {
                const veh = vehicles.find((v) => v.id === log.vehicleId);
                return (
                  <tr key={log.id} className="hover-gray-50/50 dark-zinc-800/30">
                    <td className="px-6 py-4">
                      <div>
                        <p className="font-bold text-gray-900 dark-zinc-100">{veh?.name || 'Retired Vehicle'}</p>
                        <p className="font-mono text-[10px] text-gray-400">{veh?.registrationNumber}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-gray-700 dark-zinc-300 font-medium">{log.description}</td>
                    <td className="px-6 py-4">
                      <div className="flex flex-col text-xs">
                        <span className="flex items-center text-gray-600 dark-zinc-400">
                          <Calendar className="mr-1 h-3.5 w-3.5 text-gray-400" />
                          Started{log.startDate}
                        </span>
                        {log.endDate && (
                          <span className="text-[10px] text-emerald-500 font-bold mt-0.5">
                            Completed{log.endDate}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right font-mono font-semibold text-gray-900 dark-zinc-50">${log.cost.toLocaleString()}</td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                        log.status === 'Active'
                          ? 'bg-amber-100 text-amber-800 dark-amber-950/30 dark-amber-300'
                          'bg-emerald-100 text-emerald-800 dark-emerald-950/30 dark-emerald-300'
                      }`}>
                        {log.status === 'Active' ? 'In Shop' 'Closed & Released'}
                      </span>
                    </td>
                    {isManager && (
                      <td className="px-6 py-4 text-right">
                        {log.status === 'Active' ? (
                          <button
                            onClick={() => handleOpenCloseLog(log)}
                            className="bg-indigo-50 text-indigo-600 hover-indigo-100 text-xs font-bold px-3 py-1.5 rounded-lg dark-indigo-950/30 dark-indigo-400"
                          >
                            Close Record
                          </button>
                        ) (
                          <span className="text-xs text-gray-400">Completed</span>
                        )}
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Mobile View Adaptive Layout */}
        <div className="grid gap-4 p-4 md">
          {maintenanceLogs.map((log) => {
            const veh = vehicles.find((v) => v.id === log.vehicleId);
            return (
              <div key={log.id} className="rounded-xl border border-gray-100 bg-gray-50/20 p-4 dark-zinc-800 dark-zinc-800/20">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-gray-900 dark-zinc-50">{veh?.name || 'Retired Asset'}</h4>
                    <p className="text-[10px] font-mono text-gray-400">{veh?.registrationNumber}</p>
                  </div>
                  <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-bold ${
                    log.status === 'Active'
                      ? 'bg-amber-50 text-amber-700 dark-amber-950/30 dark-amber-400'
                      'bg-emerald-50 text-emerald-700 dark-emerald-950/30 dark-emerald-400'
                  }`}>
                    {log.status === 'Active' ? 'In Shop' 'Completed'}
                  </span>
                </div>
                <div className="mt-3 text-xs text-gray-700 dark-zinc-300">
                  <p className="font-semibold">{log.description}</p>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-2 text-xs border-t border-gray-100 pt-3 dark-zinc-800/60">
                  <div>
                    <p className="text-gray-400">Started</p>
                    <p className="font-semibold text-gray-700 dark-zinc-300 font-mono">{log.startDate}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Cost</p>
                    <p className="font-semibold text-gray-700 dark-zinc-300 font-mono">${log.cost}</p>
                  </div>
                </div>

                {isManager && log.status === 'Active' && (
                  <div className="mt-4 flex justify-end border-t border-gray-100 pt-3 dark-zinc-800/60">
                    <button
                      onClick={() => handleOpenCloseLog(log)}
                      className="w-full text-center py-2 text-xs font-bold bg-indigo-600 text-white rounded-lg hover-indigo-700"
                    >
                      Close Maintenance Work Order
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>

      {/* Book Maintenance Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-md overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-2xl dark-zinc-800 dark-zinc-950">
            <div className="border-b border-gray-100 px-6 py-4 flex items-center justify-between dark-zinc-800">
              <div className="flex items-center space-x-2 text-indigo-600 dark-indigo-400">
                <Wrench className="h-5 w-5" />
                <h3 className="font-display font-bold text-gray-900 dark-zinc-50">
                  Book Vehicle for Shop
                </h3>
              </div>
              <button onClick={() => setIsOpen(false)} className="p-1 rounded-lg text-gray-400 hover-gray-100 dark-zinc-900">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitLog} className="p-6 space-y-4">
              
              {formError && (
                <div className="flex items-center space-x-2 text-rose-600 bg-rose-50/50 p-3 rounded-lg text-xs font-semibold border border-rose-100 dark-rose-950/15 dark-rose-900/50">
                  <AlertCircle className="h-4 w-4 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {formSuccess && (
                <div className="flex items-center space-x-2 text-emerald-600 bg-emerald-50/50 p-3 rounded-lg text-xs font-semibold border border-emerald-100 dark-emerald-950/15 dark-emerald-900/50">
                  <CheckCircle className="h-4 w-4 shrink-0" />
                  <span>{formSuccess}</span>
                </div>
              )}

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-gray-700 dark-zinc-400 uppercase mb-1">
                    Select Fleet Vehicle
                  </label>
                  <select
                    value={selectedVehicleId}
                    onChange={(e) => setSelectedVehicleId(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-900 dark-zinc-100"
                  >
                    {availableVehicles.length === 0 ? (
                      <option value="">-- No available vehicles to maintain --</option>
                    ) (
                      availableVehicles.map((v) => (
                        <option key={v.id} value={v.id}>
                          {v.name} ({v.registrationNumber}) - Status{v.status}
                        </option>
                      ))
                    )}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark-zinc-400 uppercase mb-1">
                    Work Description / Diagnostics
                  </label>
                  <textarea
                    required
                    rows={3}
                    placeholder="e.g. Regular 100k oil change, rotation of tires, brake pad replacements..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-900 dark-zinc-100"
                  />
                </div>

                <div className="grid gap-4 grid-cols-2">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark-zinc-400 uppercase mb-1">
                      Estimated Repair Cost ($)
                    </label>
                    <input
                      type="number"
                      required
                      min="0"
                      value={cost}
                      onChange={(e) => setCost(Number(e.target.value))}
                      className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-900 dark-zinc-100"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark-zinc-400 uppercase mb-1">
                      Date Entered Shop
                    </label>
                    <input
                      type="date"
                      required
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-900 dark-zinc-100"
                    />
                  </div>
                </div>
              </div>

              <div className="border-t border-gray-100 pt-4 flex justify-end space-x-2 dark-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="rounded-lg border border-gray-200 px-4 py-2 text-xs font-semibold text-gray-500 hover-gray-50 dark-zinc-800 dark-zinc-400 dark-zinc-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={availableVehicles.length === 0}
                  className="rounded-lg bg-indigo-600 px-4 py-2 text-xs font-bold text-white shadow-md hover-indigo-700 disabled-gray-250 dark-zinc-800"
                >
                  Book Repairs
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* Close Maintenance Modal */}
      {closingLogId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-sm overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-2xl dark-zinc-800 dark-zinc-950">
            <div className="border-b border-gray-100 px-6 py-4 flex items-center justify-between dark-zinc-800">
              <h3 className="font-display font-bold text-gray-900 dark-zinc-50">
                Close Maintenance Record
              </h3>
              <button onClick={() => setClosingLogId(null)} className="p-1 rounded-lg text-gray-400 hover-gray-100 dark-zinc-900">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCloseLog} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-700 dark-zinc-400 uppercase mb-1">
                  Final Settled Repair Cost ($)
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  value={finalCost}
                  onChange={(e) => setFinalCost(Number(e.target.value))}
                  className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-900 dark-zinc-100"
                />
              </div>

              <div className="border-t border-gray-100 pt-4 flex justify-end space-x-2 dark-zinc-800">
                <button
                  type="button"
                  onClick={() => setClosingLogId(null)}
                  className="rounded-lg border border-gray-200 px-4 py-2 text-xs font-semibold text-gray-500 hover-gray-50 dark-zinc-800 dark-zinc-400 dark-zinc-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-emerald-600 px-4 py-2 text-xs font-bold text-white shadow-md hover-emerald-700"
                >
                  Release & Set Available
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
