/**
 * @license
 * SPDX-License-Identifier-2.0
 */

import React, { useState } from 'react';
import { useTransit } from '../context/TransitContext';
import { Truck, Plus, Edit2, Trash2, ShieldAlert, X, DollarSign, Scale, Calendar, AlertCircle, CheckCircle } from 'lucide-react';
import { Vehicle, VehicleType, VehicleStatus } from '../types';

export const VehicleRegistry.FC = () => {
  const { vehicles, addVehicle, updateVehicle, deleteVehicle, currentUser } = useTransit();

  // Dialog / Modal Form State
  const [isOpen, setIsOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);

  const [regNumber, setRegNumber] = useState('');
  const [name, setName] = useState('');
  const [type, setType] = useState<VehicleType>('Semi-Truck');
  const [maxCapacity, setMaxCapacity] = useState<number>(500);
  const [odometer, setOdometer] = useState<number>(0);
  const [acquisitionCost, setAcquisitionCost] = useState<number>(20000);
  const [status, setStatus] = useState<VehicleStatus>('Available');
  const [region, setRegion] = useState('South');

  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const isManager = currentUser?.role === 'Fleet Manager';

  const resetForm = () => {
    setRegNumber('');
    setName('');
    setType('Semi-Truck');
    setMaxCapacity(500);
    setOdometer(0);
    setAcquisitionCost(20000);
    setStatus('Available');
    setRegion('South');
    setErrorMessage(null);
    setSuccessMessage(null);
    setEditId(null);
    setIsEditing(false);
  };

  const handleOpenCreate = () => {
    resetForm();
    setIsOpen(true);
  };

  const handleOpenEdit = (v) => {
    setRegNumber(v.registrationNumber);
    setName(v.name);
    setType(v.type);
    setMaxCapacity(v.maxCapacity);
    setOdometer(v.odometer);
    setAcquisitionCost(v.acquisitionCost);
    setStatus(v.status);
    setRegion(v.region);
    setEditId(v.id);
    setIsEditing(true);
    setIsOpen(true);
    setErrorMessage(null);
    setSuccessMessage(null);
  };

  const handleSubmit = (e.FormEvent) => {
    e.preventDefault();
    if (!isManager) {
      setErrorMessage('Access Denied.');
      return;
    }

    if (!regNumber || !name || maxCapacity <= 0 || odometer < 0 || acquisitionCost <= 0) {
      setErrorMessage('Please fill in all details with valid positive values.');
      return;
    }

    const vehicleData = {
      registrationNumber
      name,
      type,
      maxCapacity,
      odometer,
      acquisitionCost,
      status,
      region
    };

    let result;
    if (isEditing && editId) {
      result = updateVehicle({ ...vehicleData, id});
    } else {
      result = addVehicle(vehicleData);
    }

    if (result.success) {
      setSuccessMessage(result.message);
      setTimeout(() => {
        setIsOpen(false);
        resetForm();
      }, 1000);
    } else {
      setErrorMessage(result.message);
    }
  };

  const handleDelete = (id) => {
    if (!isManager) {
      alert('Access Denied.');
      return;
    }
    if (window.confirm('Are you sure you want to retire/delete this vehicle from the registry?')) {
      const res = deleteVehicle(id);
      if (!res.success) {
        alert(res.message);
      }
    }
  };

  return (
    <div className="space-y-6">
      
      {/* RBAC Warning Banner */}
      {!isManager && (
        <div id="rbac-warning-vehicle" className="flex items-center space-x-3 rounded-xl bg-indigo-500/10 p-4 border border-indigo-500/30 text-indigo-700 dark-indigo-400">
          <ShieldAlert className="h-5 w-5 shrink-0 text-indigo-500" />
          <div className="text-xs font-semibold">
            <span className="font-bold">Role Restricton/span> Only users with the <span className="font-bold underline text-indigo-600 dark-indigo-400">Fleet Manager</span> role can add, modify, or retire vehicles in the Registry. You are currently viewing as <span className="italic">{currentUser?.role}</span>. Use the Role switcher in the header to gain access.
          </div>
        </div>
      )}

      {/* Header action panel */}
      <div className="flex flex-col gap-4 sm-row sm-center sm-between">
        <div>
          <h2 className="font-display text-xl font-bold tracking-tight text-gray-900 dark-zinc-50">
            Vehicle Registry
          </h2>
          <p className="text-xs text-gray-500 dark-zinc-400">
            Master repository for fleet vehicles, cargo guidelines, and active telemetry states.
          </p>
        </div>
        
        {isManager && (
          <button
            onClick={handleOpenCreate}
            id="btn-register-vehicle"
            className="flex items-center justify-center space-x-2 rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-bold text-white shadow-md transition-all hover-indigo-700 active-95"
          >
            <Plus className="h-4 w-4" />
            <span>Register New Vehicle</span>
          </button>
        )}
      </div>

      {/* Vehicle Registry Table and Cards */}
      <div className="rounded-2xl border border-gray-200 bg-white shadow-sm dark-zinc-800 dark-zinc-900 overflow-hidden">
        
        {/* Desktop View Table */}
        <div className="hidden overflow-x-auto md">
          <table className="w-full border-collapse text-left text-sm text-gray-500 dark-zinc-400">
            <thead className="bg-gray-50 text-xs font-bold uppercase text-gray-700 dark-zinc-800/50 dark-zinc-300">
              <tr>
                <th className="px-6 py-4">Vehicle Model / Type</th>
                <th className="px-6 py-4">Reg Number</th>
                <th className="px-6 py-4">Max Capacity</th>
                <th className="px-6 py-4 text-right">Odometer</th>
                <th className="px-6 py-4 text-right">Acquisition Cost</th>
                <th className="px-6 py-4">Region</th>
                <th className="px-6 py-4">Status</th>
                {isManager && <th className="px-6 py-4 text-right">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 border-t border-gray-100 dark-zinc-800 dark-zinc-800">
              {vehicles.map((v) => (
                <tr key={v.id} className="hover-gray-50/50 dark-zinc-800/30">
                  <td className="px-6 py-4">
                    <div>
                      <p className="font-bold text-gray-900 dark-zinc-100">{v.name}</p>
                      <p className="text-[10px] text-gray-400 dark-zinc-500">{v.type}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="font-mono bg-gray-100 dark-zinc-800 px-2.5 py-1 rounded text-xs text-gray-800 dark-zinc-200 border border-gray-200/50 dark-zinc-700/50">
                      {v.registrationNumber}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-1 font-semibold text-gray-700 dark-zinc-300">
                      <Scale className="h-3.5 w-3.5 text-gray-400" />
                      <span>{v.maxCapacity.toLocaleString()} kg</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right font-mono text-gray-700 dark-zinc-300">{v.odometer.toLocaleString()} km</td>
                  <td className="px-6 py-4 text-right font-mono text-gray-700 dark-zinc-300">${v.acquisitionCost.toLocaleString()}</td>
                  <td className="px-6 py-4">{v.region}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                      v.status === 'Available'
                        ? 'bg-emerald-50 text-emerald-700 dark-emerald-950/30 dark-emerald-400'
                        .status === 'On Trip'
                        ? 'bg-indigo-50 text-indigo-700 dark-indigo-950/30 dark-indigo-400'
                        .status === 'In Shop'
                        ? 'bg-amber-50 text-amber-700 dark-amber-950/30 dark-amber-400'
                        'bg-rose-50 text-rose-700 dark-rose-950/30 dark-rose-400'
                    }`}>
                      {v.status}
                    </span>
                  </td>
                  {isManager && (
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end space-x-2">
                        <button
                          onClick={() => handleOpenEdit(v)}
                          className="p-1.5 text-indigo-500 hover-indigo-50 dark-indigo-950/40 rounded-lg transition-colors"
                          title="Edit vehicle details"
                        >
                          <Edit2 className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(v.id)}
                          className="p-1.5 text-rose-500 hover-rose-50 dark-rose-950/40 rounded-lg transition-colors"
                          title="Retire/delete vehicle"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile View Cards */}
        <div className="grid gap-4 p-4 md">
          {vehicles.map((v) => (
            <div key={v.id} className="rounded-xl border border-gray-100 bg-gray-50/20 p-4 dark-zinc-800 dark-zinc-800/20">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-bold text-gray-900 dark-zinc-100">{v.name}</h4>
                  <p className="text-[10px] text-gray-400">{v.type}</p>
                </div>
                <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-bold ${
                  v.status === 'Available'
                    ? 'bg-emerald-50 text-emerald-700 dark-emerald-950/30 dark-emerald-400'
                    .status === 'On Trip'
                    ? 'bg-indigo-50 text-indigo-700 dark-indigo-950/30 dark-indigo-400'
                    .status === 'In Shop'
                    ? 'bg-amber-50 text-amber-700 dark-amber-950/30 dark-amber-400'
                    'bg-rose-50 text-rose-700 dark-rose-950/30 dark-rose-400'
                }`}>
                  {v.status}
                </span>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2 text-xs border-t border-gray-100 pt-3 dark-zinc-800/60">
                <div>
                  <p className="text-gray-400">Reg Num</p>
                  <p className="font-mono font-semibold text-gray-700 dark-zinc-300">{v.registrationNumber}</p>
                </div>
                <div>
                  <p className="text-gray-400">Max Capacity</p>
                  <p className="font-semibold text-gray-700 dark-zinc-300">{v.maxCapacity} kg</p>
                </div>
                <div>
                  <p className="text-gray-400">Odometer</p>
                  <p className="font-semibold text-gray-700 dark-zinc-300 font-mono">{v.odometer} km</p>
                </div>
                <div>
                  <p className="text-gray-400">Acquisition Cost</p>
                  <p className="font-semibold text-gray-700 dark-zinc-300 font-mono">${v.acquisitionCost.toLocaleString()}</p>
                </div>
              </div>

              {isManager && (
                <div className="mt-4 flex justify-end space-x-2 border-t border-gray-100 pt-3 dark-zinc-800/60">
                  <button
                    onClick={() => handleOpenEdit(v)}
                    className="flex items-center space-x-1.5 px-3 py-1.5 text-xs text-indigo-600 bg-indigo-50 rounded-lg font-bold dark-indigo-950/30 dark-indigo-400"
                  >
                    <Edit2 className="h-3 w-3" />
                    <span>Edit</span>
                  </button>
                  <button
                    onClick={() => handleDelete(v.id)}
                    className="flex items-center space-x-1.5 px-3 py-1.5 text-xs text-rose-600 bg-rose-50 rounded-lg font-bold dark-rose-950/30 dark-rose-400"
                  >
                    <Trash2 className="h-3 w-3" />
                    <span>Delete</span>
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>

      </div>

      {/* Register/Edit Vehicle Dialog */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-lg overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-2xl dark-zinc-800 dark-zinc-950">
            <div className="border-b border-gray-100 px-6 py-4 flex items-center justify-between dark-zinc-800">
              <div className="flex items-center space-x-2 text-indigo-600 dark-indigo-400">
                <Truck className="h-5 w-5" />
                <h3 className="font-display font-bold text-gray-900 dark-zinc-50">
                  {isEditing ? 'Modify Fleet Asset' 'Register Fleet Asset'}
                </h3>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1 rounded-lg text-gray-400 hover-gray-100 dark-zinc-900"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              
              {errorMessage && (
                <div className="flex items-center space-x-2 text-rose-600 bg-rose-50/50 p-3 rounded-lg text-xs font-semibold border border-rose-100 dark-rose-950/15 dark-rose-900/50">
                  <AlertCircle className="h-4 w-4 shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {successMessage && (
                <div className="flex items-center space-x-2 text-emerald-600 bg-emerald-50/50 p-3 rounded-lg text-xs font-semibold border border-emerald-100 dark-emerald-950/15 dark-emerald-900/50">
                  <CheckCircle className="h-4 w-4 shrink-0" />
                  <span>{successMessage}</span>
                </div>
              )}

              <div className="grid gap-4 sm-cols-2">
                <div>
                  <label className="block text-xs font-bold text-gray-700 dark-zinc-400 uppercase mb-1">
                    Registration Number (Unique)
                  </label>
                  <input
                    type="text"
                    required
                    disabled={isEditing} // registration cannot be changed after creation to enforce DB consistency
                    placeholder="e.g. TX-420-CDX"
                    value={regNumber}
                    onChange={(e) => setRegNumber(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus-none focus-2 focus-indigo-500 disabled-gray-50 dark-zinc-800 dark-zinc-900 dark-zinc-100 dark-zinc-900/50"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark-zinc-400 uppercase mb-1">
                    Model / Name
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Ford Transit, Rivian EDV"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-900 dark-zinc-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark-zinc-400 uppercase mb-1">
                    Vehicle Type
                  </label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as VehicleType)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-900 dark-zinc-100"
                  >
                    <option value="Semi-Truck">Semi-Truck</option>
                    <option value="Box Truck">Box Truck</option>
                    <option value="Cargo Van">Cargo Van</option>
                    <option value="Flatbed">Flatbed</option>
                    <option value="EV Delivery Van">EV Delivery Van</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark-zinc-400 uppercase mb-1">
                    Max Load Capacity (kg)
                  </label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={maxCapacity}
                    onChange={(e) => setMaxCapacity(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-900 dark-zinc-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark-zinc-400 uppercase mb-1">
                    Starting Odometer (km)
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    value={odometer}
                    onChange={(e) => setOdometer(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-900 dark-zinc-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark-zinc-400 uppercase mb-1">
                    Acquisition Cost (USD)
                  </label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={acquisitionCost}
                    onChange={(e) => setAcquisitionCost(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-900 dark-zinc-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark-zinc-400 uppercase mb-1">
                    Regional Scope
                  </label>
                  <select
                    value={region}
                    onChange={(e) => setRegion(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-900 dark-zinc-100"
                  >
                    <option value="South">South</option>
                    <option value="West">West</option>
                    <option value="East">East</option>
                    <option value="Midwest">Midwest</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 dark-zinc-400 uppercase mb-1">
                    Telemetry Status
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as VehicleStatus)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs text-gray-900 focus-none focus-2 focus-indigo-500 dark-zinc-800 dark-zinc-900 dark-zinc-100"
                  >
                    <option value="Available">Available</option>
                    <option value="On Trip">On Trip</option>
                    <option value="In Shop">In Shop</option>
                    <option value="Retired">Retired</option>
                  </select>
                </div>
              </div>

              <div className="border-t border-gray-100 pt-4 flex justify-end space-x-2 dark-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="rounded-lg border border-gray-200 px-4 py-2 text-xs font-semibold text-gray-500 hover-gray-50 dark-zinc-800 dark-zinc-400 dark-zinc-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-indigo-600 px-4 py-2 text-xs font-bold text-white shadow-md hover-indigo-700"
                >
                  {isEditing ? 'Save Asset' 'Register Asset'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
