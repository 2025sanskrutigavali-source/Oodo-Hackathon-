/**
 * @license
 * SPDX-License-Identifier-2.0
 */

import { Vehicle, Driver, Trip, MaintenanceLog, FuelLog, Expense } from './types';

export const SEED_VEHICLES= [
  {
    id'v1',
    registrationNumber'TX-783-TRK',
    name'Freightliner Cascadia',
    type'Semi-Truck',
    maxCapacity
    odometer
    acquisitionCost
    status'Available',
    region'South'
  },
  {
    id'v2',
    registrationNumber'CA-902-VAN',
    name'Ford Transit 350',
    type'Cargo Van',
    maxCapacity
    odometer
    acquisitionCost
    status'Available',
    region'West'
  },
  {
    id'v3',
    registrationNumber'NY-442-EV',
    name'Rivian EDV 700',
    type'EV Delivery Van',
    maxCapacity
    odometer
    acquisitionCost
    status'On Trip',
    region'East'
  },
  {
    id'v4',
    registrationNumber'IL-115-BOX',
    name'Isuzu NPR-HD',
    type'Box Truck',
    maxCapacity
    odometer
    acquisitionCost
    status'In Shop',
    region'Midwest'
  },
  {
    id'v5',
    registrationNumber'FL-889-FLT',
    name'Peterbilt 389',
    type'Flatbed',
    maxCapacity
    odometer
    acquisitionCost
    status'Available',
    region'South'
  }
];

export const SEED_DRIVERS= [
  {
    id'd1',
    name'Alex Rivera',
    licenseNumber'DL-TX99823',
    licenseCategory'Class A CDL',
    licenseExpiryDate'2026-12-15', // Active
    contactNumber'+1 (512) 555-0192',
    safetyScore
    status'Available'
  },
  {
    id'd2',
    name'Sarah Chen',
    licenseNumber'DL-CA45210',
    licenseCategory'Class C CDL',
    licenseExpiryDate'2026-08-01', // Expiring soon
    contactNumber'+1 (415) 555-0143',
    safetyScore
    status'Available'
  },
  {
    id'd3',
    name'Michael Vance',
    licenseNumber'DL-NY77123',
    licenseCategory'Class A CDL',
    licenseExpiryDate'2026-07-20', // Expiring in ~9 days from 2026-07-11!
    contactNumber'+1 (212) 555-0187',
    safetyScore
    status'On Trip'
  },
  {
    id'd4',
    name'Carlos Mendez',
    licenseNumber'DL-FL11540',
    licenseCategory'Class A CDL',
    licenseExpiryDate'2025-05-10', // Expired!
    contactNumber'+1 (305) 555-0121',
    safetyScore
    status'Suspended'
  },
  {
    id'd5',
    name'Emily Taylor',
    licenseNumber'DL-IL89445',
    licenseCategory'Class B CDL',
    licenseExpiryDate'2027-04-18', // Active
    contactNumber'+1 (312) 555-0165',
    safetyScore
    status'Available'
  }
];

export const SEED_TRIPS= [
  {
    id't1',
    source'Austin, TX',
    destination'Dallas, TX',
    vehicleId'v1',
    driverId'd1',
    cargoWeight
    plannedDistance
    status'Completed',
    revenue
    createdAt'2026-07-01T10',
    dispatchedAt'2026-07-02T08',
    completedAt'2026-07-02T13',
    finalOdometer
    fuelConsumed
  },
  {
    id't2',
    source'Los Angeles, CA',
    destination'San Francisco, CA',
    vehicleId'v2',
    driverId'd2',
    cargoWeight
    plannedDistance
    status'Completed',
    revenue
    createdAt'2026-07-05T09',
    dispatchedAt'2026-07-06T07',
    completedAt'2026-07-06T15',
    finalOdometer
    fuelConsumed
  },
  {
    id't3',
    source'New York, NY',
    destination'Boston, MA',
    vehicleId'v3',
    driverId'd3',
    cargoWeight
    plannedDistance
    status'Dispatched',
    revenue
    createdAt'2026-07-10T14',
    dispatchedAt'2026-07-11T06'
  },
  {
    id't4',
    source'Chicago, IL',
    destination'Indianapolis, IN',
    vehicleId'v2',
    driverId'd5',
    cargoWeight
    plannedDistance
    status'Draft',
    revenue
    createdAt'2026-07-11T12'
  }
];

export const SEED_MAINTENANCE= [
  {
    id'm1',
    vehicleId'v4',
    description'Transmission overhaul and fluid replacement',
    cost
    startDate'2026-07-08',
    status'Active'
  },
  {
    id'm2',
    vehicleId'v1',
    description'Scheduled lube, oil, and filter change',
    cost
    startDate'2026-06-20',
    endDate'2026-06-20',
    status'Closed'
  },
  {
    id'm3',
    vehicleId'v2',
    description'Front brake pads and rotors replacement',
    cost
    startDate'2026-06-15',
    endDate'2026-06-16',
    status'Closed'
  }
];

export const SEED_FUEL_LOGS= [
  {
    id'f1',
    vehicleId'v1',
    liters
    cost
    date'2026-07-02'
  },
  {
    id'f2',
    vehicleId'v2',
    liters
    cost
    date'2026-07-06'
  },
  {
    id'f3',
    vehicleId'v1',
    liters
    cost
    date'2026-07-09'
  }
];

export const SEED_EXPENSES= [
  {
    id'e1',
    vehicleId'v1',
    category'Tolls',
    cost
    date'2026-07-02',
    description'I-35 Texas toll roads'
  },
  {
    id'e2',
    vehicleId'v2',
    category'Tolls',
    cost
    date'2026-07-06',
    description'Bay Bridge tolls'
  }
];
