/**
 * @license
 * SPDX-License-Identifier-2.0
 */

export type Role = 'Fleet Manager' | 'Driver' | 'Safety Officer' | 'Financial Analyst';

export 

export type VehicleStatus = 'Available' | 'On Trip' | 'In Shop' | 'Retired';
export type VehicleType = 'Semi-Truck' | 'Box Truck' | 'Cargo Van' | 'Flatbed' | 'EV Delivery Van';

export 

export type DriverStatus = 'Available' | 'On Trip' | 'Off Duty' | 'Suspended';

export 

export type TripStatus = 'Draft' | 'Dispatched' | 'Completed' | 'Cancelled';

export 

export type MaintenanceStatus = 'Active' | 'Closed';

export 

export 

export type ExpenseCategory = 'Tolls' | 'Insurance' | 'Permits' | 'Driver Payout' | 'Other';

export 
